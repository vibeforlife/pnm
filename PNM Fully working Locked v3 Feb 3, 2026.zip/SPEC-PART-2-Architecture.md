# Poker Night Manager - Technical Specification
## Part 2: Technical Architecture & Data Model

---

## 1. System Architecture

### 1.1 High-Level Architecture

```
┌─────────────┐
│   Browser   │
│  (Client)   │
└──────┬──────┘
       │
       │ HTTPS
       │
       ▼
┌─────────────────────────────────┐
│   Firebase Services (Google)    │
│                                 │
│  ┌──────────────────────────┐  │
│  │  Firestore Database      │  │
│  │  (NoSQL Document Store)  │  │
│  └──────────────────────────┘  │
│                                 │
│  ┌──────────────────────────┐  │
│  │  Firebase Hosting        │  │
│  │  (Optional CDN)          │  │
│  └──────────────────────────┘  │
└─────────────────────────────────┘
```

**Data Flow:**
```
User Action → JavaScript Event → 
Update Local State → 
Save to Firestore → 
Real-time Listener Fires → 
Update UI for All Users
```

---

### 1.2 Technology Stack

**Frontend:**
```
HTML5 (Semantic markup)
├── CSS3 (Custom properties, Grid, Flexbox)
├── JavaScript ES6+ (Vanilla, no framework)
├── Chart.js 3.9.1 (Data visualization)
└── Google Fonts (Outfit, Space Mono)
```

**Backend:**
```
Firebase Platform
├── Firestore (Database)
├── Firebase SDK 10.8.0 (Client library)
└── Firebase Hosting (Optional)
```

**Development:**
```
No build tools required
├── No transpilation
├── No bundling
├── No package manager
└── Direct browser execution
```

---

### 1.3 File Architecture

```
poker-night-manager/
│
├── index.html                    # Landing page (27KB)
│   ├── Group creation UI
│   ├── Group joining UI
│   └── My Groups list
│
├── admin.html                    # Admin interface (98KB)
│   ├── Dashboard tab
│   ├── Poker Nights tab (with search/sort)
│   ├── Players tab (with search/sort)
│   ├── Leaderboard tab (with year filter)
│   ├── Stats tab
│   ├── Settlement tab (with tracking)
│   └── Links to wrapped & achievements
│
├── viewer.html                   # Viewer interface (90KB)
│   ├── Same tabs as admin (read-only)
│   ├── All search/sort/filter features
│   └── No edit/delete capabilities
│
├── wrapped.html                  # Year-end review (29KB)
│   ├── Period/player selectors
│   ├── Gradient stat cards
│   ├── Fortune cookie feature
│   └── Back navigation with source detection
│
├── achievements-enhanced.html    # Achievement system (25KB)
│   ├── 20+ achievement types
│   ├── Year/player/badge filters
│   ├── Anniversary tracking
│   └── Back navigation with source detection
│
└── firestore.rules               # Security rules (<1KB)
    └── Access control definitions
```

**Inter-File Communication:**
- URL parameters: `?group=CODE&source=admin`
- localStorage: User's group memberships
- Firebase: Shared data store

---

## 2. Data Model

### 2.1 Firestore Structure

**Collection:** `groups`  
**Document ID:** Group code (e.g., "POKER-X7Y2")

**Complete Schema:**
```javascript
{
  // ========================================
  // METADATA
  // ========================================
  "id": "POKER-X7Y2",
  "name": "Friday Night Poker",
  "createdAt": "2024-02-01T10:00:00.000Z",
  "currentYear": 2024,
  
  // ========================================
  // AUTHENTICATION
  // ========================================
  "adminPasswordHash": "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8",
  "viewerPasswordHash": "6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b",
  // SHA-256 hashes, never store plain text
  
  // ========================================
  // PLAYERS
  // ========================================
  "players": [
    "Alice",
    "Bob",
    "Charlie",
    "David"
  ],
  // Simple string array, alphabetical by convention
  
  "playerInfo": {
    "Alice": {
      "dateAdded": "2024-02-01T15:30:00.000Z"
      // ISO 8601 timestamp, used for anniversary achievements
    },
    "Bob": {
      "dateAdded": "2024-02-01T15:31:00.000Z"
    },
    "Charlie": {
      "dateAdded": "2024-02-05T18:00:00.000Z"
    },
    "David": {
      "dateAdded": "2024-02-10T19:15:00.000Z"
    }
  },
  
  // ========================================
  // POKER NIGHTS
  // ========================================
  "nights": [
    {
      // Basic Info
      "date": "2024-02-05",
      // YYYY-MM-DD format, stored as string
      
      "location": "Bob's House",
      // Optional, free text
      
      "buyIn": 20,
      // Standard buy-in amount, number (dollars)
      
      "notes": "Epic comeback by Alice!",
      // Optional, free text
      
      "settled": false,
      // Boolean, tracks if this night's debts are paid
      
      // Player Results
      "results": [
        {
          "player": "Alice",
          // Must match name in players array
          
          "totalBuyIn": 40,
          // Total invested including rebuys, number
          
          "cashOut": 70,
          // Amount cashed out at end, number
          
          "winnings": 30
          // Calculated: cashOut - totalBuyIn, number
        },
        {
          "player": "Bob",
          "totalBuyIn": 20,
          "cashOut": 5,
          "winnings": -15
        },
        {
          "player": "Charlie",
          "totalBuyIn": 20,
          "cashOut": 5,
          "winnings": -15
        }
      ],
      
      // Expenses
      "expenses": [
        {
          "paidBy": "Alice",
          // Must match name in players array
          
          "amount": 30,
          // Dollar amount, number
          
          "description": "Pizza"
          // Optional, free text
        },
        {
          "paidBy": "Bob",
          "amount": 15,
          "description": "Drinks"
        }
      ]
    }
    // ... more nights
  ],
  
  // ========================================
  // SETTLEMENT TRACKING
  // ========================================
  "settledTransactions": [
    {
      "from": "Bob",
      // Debtor player name
      
      "to": "Alice",
      // Creditor player name
      
      "amount": 25.00,
      // Dollar amount, number with 2 decimals
      
      "settledDate": "2024-02-05T22:30:00.000Z"
      // When marked as paid, ISO 8601 timestamp
    }
    // ... more settled transactions
  ],
  
  // ========================================
  // ARCHIVE (Future Use)
  // ========================================
  "archivedYears": {},
  // Reserved for archiving old years
  // Not currently implemented
  
  // ========================================
  // SETTINGS
  // ========================================
  "settings": {
    "currency": "$",
    // Symbol to display, 1-3 characters
    
    "defaultBuyIn": 20
    // Pre-fill value for new nights, number
  }
}
```

---

### 2.2 Data Type Specifications

**String Fields:**
- id, name, location, notes, description
- player names
- date (YYYY-MM-DD format)
- ISO timestamps (YYYY-MM-DDTHH:MM:SS.SSSZ)

**Number Fields:**
- buyIn, totalBuyIn, cashOut, winnings, amount
- currentYear
- All stored as JavaScript numbers (IEEE 754)
- Currency values: 2 decimal precision

**Boolean Fields:**
- settled

**Array Fields:**
- players (string array)
- nights (object array)
- results (object array)
- expenses (object array)
- settledTransactions (object array)

**Object Fields:**
- playerInfo (map of player name → info object)
- archivedYears (reserved)
- settings (configuration object)

---

### 2.3 Calculated Fields (Never Stored)

These are computed on-the-fly from stored data:

**Player Statistics:**
```javascript
{
  name: "Alice",
  totalWinnings: 250.00,      // Sum of winnings in period
  gamesPlayed: 10,             // Count of games
  wins: 6,                     // Count where winnings > 0
  winRate: 60,                 // (wins / gamesPlayed) * 100
  biggestWin: 150.00,          // Max single winnings
  biggestLoss: -50.00,         // Min single winnings
  avgPerGame: 25.00            // totalWinnings / gamesPlayed
}
```

**Streaks:**
```javascript
{
  consecutiveWins: 3,          // Current win streak
  maxConsecutiveWins: 5,       // Best ever streak in period
  consecutiveNoBust: 7,        // Current no-bust streak (winnings ≥ 0)
  maxConsecutiveNoBust: 10     // Best ever no-bust streak
}
```

**Monthly Breakdowns:**
```javascript
{
  monthlyWinnings: {
    "2024-01": 120.00,
    "2024-02": -30.00,
    "2024-03": 80.00
  }
}
```

**Opponents Tracking:**
```javascript
{
  opponents: {
    "Bob": 8,        // Played against Bob 8 times
    "Charlie": 6,
    "David": 4
  },
  favoriteOpponent: "Bob"  // Most frequent
}
```

**Settlement Transactions:**
```javascript
{
  from: "Bob",
  to: "Alice",
  amount: 25.00
}
// Calculated from balances, not stored in night data
```

**Achievement Status:**
```javascript
{
  icon: "💰",
  name: "Big Winner",
  player: "Alice",
  description: "Won $150.00 in a single night",
  date: "2024-02-05",
  category: "money",
  isAnniversary: false
}
// Calculated from night data + playerInfo
```

---

### 2.4 localStorage Schema

**Key:** `"userGroups"`  
**Value:** JSON array of group memberships

```javascript
[
  {
    "groupId": "POKER-X7Y2",
    "groupName": "Friday Night Poker",
    "role": "admin",  // or "viewer"
    "lastAccessed": "2024-02-05T15:30:00.000Z"
  },
  {
    "groupId": "MONTHLY-TOUR",
    "groupName": "Monthly Tournament",
    "role": "viewer",
    "lastAccessed": "2024-01-15T20:00:00.000Z"
  }
]
```

**Operations:**
- Read on page load (index.html)
- Add when creating/joining group
- Update lastAccessed when entering group
- Sort by lastAccessed (descending) for display
- Never synced to server (browser-specific)

---

### 2.5 Data Validation Rules

**Group Level:**
```javascript
// Group ID
- Length: exactly 8 characters (including hyphen)
- Format: XXXX-XXXX
- Characters: A-Z (uppercase), 2-9 (no 0,1)
- Must be unique across all groups

// Group Name
- Required
- Max length: 30 characters
- Free text

// Passwords
- Min length: 6 characters
- No max length (reasonable limit ~50)
- Admin password: Required
- Viewer password: Optional
```

**Player Level:**
```javascript
// Player Name
- Required
- Must be unique within group
- Recommended max: 20 characters
- Free text (supports unicode)

// Date Added
- Auto-generated on player creation
- ISO 8601 format
- Immutable (doesn't change on edit)
```

**Night Level:**
```javascript
// Date
- Required
- Format: YYYY-MM-DD
- Must be valid date
- Can be future date (for planning)

// Location
- Optional
- Free text
- Recommended max: 50 characters

// Buy-in
- Required
- Number > 0
- Decimal precision: 2 places

// Notes
- Optional
- Free text
- Recommended max: 500 characters
```

**Player Result Level:**
```javascript
// Player
- Required
- Must exist in group's players array

// Total Buy-in
- Required
- Number ≥ 0
- Decimal precision: 2 places
- Should be multiple of standard buy-in (not enforced)

// Cash Out
- Required
- Number ≥ 0
- Decimal precision: 2 places

// Winnings (calculated)
- cashOut - totalBuyIn
- Can be negative
- Stored for performance (not recalculated every time)

// Validation
- Sum(totalBuyIn) should equal Sum(cashOut) within $0.01
- Enforced via live balance check UI
- Warning if unbalanced, but save still allowed
```

**Expense Level:**
```javascript
// Paid By
- Required
- Must exist in night's results array

// Amount
- Required
- Number > 0
- Decimal precision: 2 places

// Description
- Optional
- Free text
- Recommended max: 100 characters
```

---

### 2.6 Data Integrity Constraints

**Referential Integrity:**
```
✅ Player in night.results must exist in group.players
✅ Player in expense.paidBy must exist in night.results
✅ settledTransaction.from must exist in group.players
✅ settledTransaction.to must exist in group.players
```

**Business Rules:**
```
✅ Total buy-ins should equal total cash outs (within $0.01 tolerance)
✅ At least one player per night
✅ Winnings sum to zero within rounding errors
✅ Player names unique within group
✅ Group codes unique across system
```

**Soft Constraints (Warnings, Not Errors):**
```
⚠️ Night without player results (allowed for placeholder nights)
⚠️ Unbalanced buy-in/cash-out (allowed with warning)
⚠️ Future dates (allowed for planning)
⚠️ Negative cash out (unusual but allowed)
```

---

## 3. Firebase Configuration

### 3.1 Project Setup

**Firebase Project ID:** `pnm-fx2`

**Services Used:**
- Firestore Database (production mode)
- Firebase Hosting (optional)

**Services NOT Used:**
- Authentication (using custom password system)
- Realtime Database (using Firestore instead)
- Cloud Functions (all logic client-side)
- Storage (no file uploads in V3)

---

### 3.2 Firestore Security Rules

**File:** `firestore.rules`

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Groups collection
    match /groups/{groupId} {
      // Allow anyone to read group documents
      // (Needed for password verification during login)
      allow read: if true;
      
      // Allow anyone to create a new group
      // (No auth required to create groups)
      allow create: if true;
      
      // Allow anyone to update groups
      // (Password verification done client-side)
      allow update: if true;
      
      // Block deletes
      // (Groups are permanent, only archive)
      allow delete: if false;
    }
  }
}
```

**Security Model Explanation:**

**Why `allow read: if true`?**
- Users need to read group to verify password
- Group codes act as passwords (you can't find groups without the code)
- Reading a group doesn't expose sensitive data (passwords are hashed)

**Why `allow update: if true`?**
- Password verification happens client-side via hash comparison
- Only users with correct password can access the app
- Simpler than Firebase Authentication for this use case

**Why `allow delete: if false`?**
- Groups are never deleted, only archived
- Prevents accidental data loss
- Can be manually deleted via Firebase Console if needed

**Future Enhancement:**
```javascript
// V4 could add Firebase Auth and stricter rules:
allow update: if request.auth != null && 
              hasValidPassword(request.auth.token.groupId);
```

---

### 3.3 Firebase SDK Integration

**Import Pattern (ES6 Modules):**
```html
<script type="module">
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
  import { 
    getFirestore, 
    doc, 
    getDoc, 
    updateDoc, 
    onSnapshot 
  } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

  const firebaseConfig = {
    apiKey: "AIzaSyDRFKc8fr96RNryd9r7OOco-xoQlf_ZcFg",
    authDomain: "pnm-fx2.firebaseapp.com",
    projectId: "pnm-fx2",
    storageBucket: "pnm-fx2.firebasestorage.app",
    messagingSenderId: "186393450910",
    appId: "1:186393450910:web:1acfae1bee6e46b718de8f"
  };

  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);

  // Expose to global scope for non-module code
  window.db = db;
  window.firestore = { doc, getDoc, updateDoc, onSnapshot };
  window.firebaseReady = true;
  
  // Trigger app init if already defined
  if (window.init) {
    window.init();
  }
</script>
```

**Why This Pattern:**
- Firebase SDK uses ES6 modules
- Main app code uses regular scripts (easier to understand)
- window.firebaseReady flag prevents race conditions
- Graceful degradation if CDN is slow

---

### 3.4 Firestore Operations

**Read Group:**
```javascript
const groupRef = firestore.doc(db, 'groups', groupId);
const groupSnap = await firestore.getDoc(groupRef);

if (groupSnap.exists()) {
  const groupData = groupSnap.data();
  // Use data
} else {
  // Group not found
}
```

**Write Group:**
```javascript
const groupRef = firestore.doc(db, 'groups', groupId);
await firestore.updateDoc(groupRef, groupData);
// Updates entire document
```

**Real-time Listener:**
```javascript
const groupRef = firestore.doc(db, 'groups', groupId);

firestore.onSnapshot(groupRef, (doc) => {
  if (doc.exists()) {
    groupData = doc.data();
    updateUI();
  }
});

// Automatically fires when:
// - Initial data loads
// - Any field changes (from any user)
// - Runs continuously until page closed
```

---

### 2.7 Data Migration & Versioning

**Version Detection:**
```javascript
// Check for new fields and initialize if missing
if (!groupData.playerInfo) {
  groupData.playerInfo = {};
}

if (!groupData.settledTransactions) {
  groupData.settledTransactions = [];
}

// Backfill player info for existing players
groupData.players.forEach(player => {
  if (!groupData.playerInfo[player]) {
    groupData.playerInfo[player] = {
      dateAdded: groupData.createdAt || new Date().toISOString()
    };
  }
});
```

**Backward Compatibility:**
```javascript
// Old data structure (V1)
result: {
  player: "Alice",
  winnings: 30  // Just winnings, no buy-in/cash-out tracking
}

// Handle in code
const buyIn = result.totalBuyIn !== undefined 
  ? result.totalBuyIn 
  : night.buyIn;  // Fallback to standard buy-in

const cashOut = result.cashOut !== undefined
  ? result.cashOut
  : result.winnings + buyIn;  // Calculate from winnings
```

---

## 4. State Management

### 4.1 Global State

**Each page maintains:**
```javascript
let groupData = null;    // Complete group document from Firestore
let groupId = null;      // Current group code (from URL param)
let leaderboardChart = null;  // Chart.js instance (prevent memory leaks)
```

**State Initialization:**
```javascript
async function init() {
  // 1. Wait for Firebase SDK
  if (!window.firebaseReady) {
    setTimeout(init, 100);
    return;
  }
  
  // 2. Extract group ID from URL
  const urlParams = new URLSearchParams(window.location.search);
  groupId = urlParams.get('group');
  
  if (!groupId) {
    window.location.href = 'index.html';
    return;
  }
  
  // 3. Load initial data
  await loadGroupData();
  
  // 4. Set up real-time listener
  const groupRef = firestore.doc(db, 'groups', groupId);
  firestore.onSnapshot(groupRef, (doc) => {
    if (doc.exists()) {
      groupData = doc.data();
      updateUI();  // Refresh current view
    }
  });
}
```

**State Updates:**
```
User Action → Modify groupData → Save to Firestore → 
Real-time Listener Fires → groupData Updated → updateUI()
```

---

### 4.2 UI Update Strategy

**Selective Updates (Not Full Re-render):**
```javascript
function updateUI() {
  if (!groupData) return;

  // Always update header
  document.getElementById('headerGroupName').textContent = groupData.name;
  document.getElementById('headerGroupCode').textContent = groupData.id;

  // Update only the active tab
  const activeTab = document.querySelector('.tab.active');
  if (activeTab) {
    const tabName = extractTabName(activeTab);
    
    // Call specific load function
    if (tabName === 'dashboard') updateDashboard();
    else if (tabName === 'nights') loadNights();
    else if (tabName === 'players') loadPlayers();
    // ... etc
  }
}
```

**Why Not Full Re-render:**
- Preserves scroll position
- Doesn't clear search/filter inputs
- Smoother user experience
- Better performance

---

## 5. URL Routing & Navigation

### 5.1 URL Parameter Schema

**Primary Parameter:**
```
?group=GROUP-CODE
```
- Required on all pages except index.html
- Identifies which group's data to load

**Secondary Parameter:**
```
?source=admin  or  ?source=viewer
```
- Used by wrapped.html and achievements-enhanced.html
- Determines where back button returns to
- Defaults to "admin" if missing

**Examples:**
```
index.html
  (no parameters)

admin.html?group=POKER-X7Y2
  (admin viewing group POKER-X7Y2)

viewer.html?group=POKER-X7Y2
  (viewer viewing group POKER-X7Y2)

wrapped.html?source=admin&group=POKER-X7Y2
  (came from admin, will return to admin)

wrapped.html?source=viewer&group=POKER-X7Y2
  (came from viewer, will return to viewer)

achievements-enhanced.html?source=viewer&group=POKER-X7Y2
  (came from viewer, will return to viewer)
```

---

### 5.2 Navigation Patterns

**Between Main Pages:**
```javascript
// Login page to admin/viewer
window.location.href = `admin.html?group=${groupCode}`;
window.location.href = `viewer.html?group=${groupCode}`;

// Admin/Viewer to sub-pages
window.location.href = `wrapped.html?source=admin&group=${groupId}`;
window.location.href = `achievements-enhanced.html?source=viewer&group=${groupId}`;

// Sub-pages back to main
function goBack() {
  const urlParams = new URLSearchParams(window.location.search);
  const source = urlParams.get('source') || 'admin';
  window.location.href = `${source}.html?group=${groupId}`;
}
```

**Tab Navigation (Within admin.html):**
```javascript
function switchTab(tabName) {
  // Update tab styling
  document.querySelectorAll('.tab').forEach(t => {
    t.classList.remove('active');
    if (t.textContent.toLowerCase().includes(tabName)) {
      t.classList.add('active');
    }
  });
  
  // Update content visibility
  document.querySelectorAll('.tab-content').forEach(c => {
    c.classList.remove('active');
  });
  document.getElementById(tabName).classList.add('active');
  
  // Load tab-specific data
  loadTabData(tabName);
}
```

**Special Navigation (Achievements & Wrapped Tabs):**
```javascript
// These tabs redirect to separate pages instead of switching content
<div class="tab" onclick="window.location.href='wrapped.html?source=admin&group=' + groupId">
  🎁 Wrapped
</div>
```

---

## 6. Error Handling Strategy

### 6.1 Error Categories

**Network Errors:**
```javascript
try {
  await firestore.updateDoc(groupRef, groupData);
} catch (error) {
  console.error('Error saving:', error);
  showToast('Error saving data: ' + error.message, true);
  // Allow user to retry
}
```

**Validation Errors:**
```javascript
if (!name) {
  showToast('Please enter a player name', true);
  return;  // Don't proceed
}

if (password.length < 6) {
  showToast('Password must be at least 6 characters', true);
  return;
}
```

**Data Errors:**
```javascript
if (!groupSnap.exists()) {
  alert('Group not found');
  window.location.href = 'index.html';
  return;
}

// Graceful degradation for missing fields
const buyIn = result.totalBuyIn !== undefined 
  ? result.totalBuyIn 
  : night.buyIn;  // Use default if new field missing
```

---

### 6.2 Error Display Methods

**Toast Notifications (Non-blocking):**
```javascript
function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = 'toast show' + (isError ? ' error' : '');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// Usage
showToast('Player added!');  // Success (green)
showToast('Invalid password', true);  // Error (red)
```

**Alert Dialogs (Blocking):**
```javascript
// For critical errors only
alert('Group not found. Please check the code and try again.');
```

**Confirmation Dialogs:**
```javascript
if (!confirm('Delete this player? This will remove them from all games.')) {
  return;  // User cancelled
}
// Proceed with deletion
```

**Inline Error Messages:**
```html
<div class="error-message" id="createError"></div>

<script>
function showError(elementId, message) {
  const errorEl = document.getElementById(elementId);
  errorEl.textContent = message;
  errorEl.classList.add('show');
  setTimeout(() => errorEl.classList.remove('show'), 5000);
}
</script>
```

---

### 6.3 Logging Strategy

**Development Mode:**
```javascript
console.log('Init called, checking Firebase...');
console.log('Firebase ready, proceeding...');
console.log('Saving group data...', groupData);
console.log('Found player result divs:', resultDivs.length);
```

**Production Mode:**
```javascript
// Keep error logs only
console.error('Error saving:', error);
console.error('Group data not loaded');
```

**User-Facing Errors:**
- Never show raw errors to users
- Always provide actionable message
- Log technical details to console for debugging

---

## 7. Performance Considerations

### 7.1 Optimization Techniques

**Chart Management:**
```javascript
// Destroy before recreating (prevent memory leaks)
if (leaderboardChart) {
  leaderboardChart.destroy();
}
leaderboardChart = new Chart(ctx, config);
```

**Lazy Loading:**
```javascript
// Only create chart when tab is visible
function loadLeaderboard() {
  if (!document.getElementById('leaderboard').classList.contains('active')) {
    return;  // Don't load if not visible
  }
  updateLeaderboardChart(playerStats);
}
```

**Debouncing (Not Currently Implemented):**
```javascript
// For future: Debounce search input if dataset grows large
let searchTimeout;
function handleSearch() {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    performSearch();
  }, 300);
}
```

**Data Caching:**
```javascript
// groupData cached in memory
// Re-used across tab switches
// Only re-fetched on page load or real-time update
```

---

### 7.2 Firebase Usage Optimization

**Minimize Reads:**
- Use onSnapshot (real-time listener) instead of repeated getDoc calls
- One read per page load + real-time updates
- Don't fetch entire collection (only specific document)

**Minimize Writes:**
- Batch UI changes before saving
- Only save on explicit user action (Save button)
- Don't auto-save on every keystroke

**Estimated Usage (per group, per month):**
```
Reads:
- 30 page loads × 30 users = 900 reads
- Real-time updates = minimal additional reads
Total: ~1,000 reads/month

Writes:
- 4 poker nights × 1 admin = 4 writes
- 2 player edits = 2 writes
- 10 settlement marks = 10 writes
Total: ~20 writes/month

Well within free tier (50K reads, 20K writes/day)
```

---

## 8. Browser Storage

### 8.1 localStorage Usage

**Purpose:** Store user's group memberships for quick access

**Key-Value:**
```javascript
Key: "userGroups"
Value: JSON string of array

Example:
localStorage.setItem('userGroups', JSON.stringify([
  {
    groupId: "POKER-X7Y2",
    groupName: "Friday Night Poker",
    role: "admin",
    lastAccessed: "2024-02-05T15:30:00.000Z"
  }
]));
```

**Operations:**
```javascript
// Read
const userGroups = JSON.parse(localStorage.getItem('userGroups') || '[]');

// Add/Update
function saveUserGroup(groupId, groupName, role) {
  let userGroups = JSON.parse(localStorage.getItem('userGroups') || '[]');
  
  const existingIndex = userGroups.findIndex(g => g.groupId === groupId);
  
  if (existingIndex >= 0) {
    // Update existing
    userGroups[existingIndex] = {
      groupId,
      groupName,
      role,
      lastAccessed: new Date().toISOString()
    };
  } else {
    // Add new
    userGroups.push({
      groupId,
      groupName,
      role,
      lastAccessed: new Date().toISOString()
    });
  }
  
  localStorage.setItem('userGroups', JSON.stringify(userGroups));
}

// No delete operation (user can manually clear if needed)
```

**Considerations:**
- 5-10MB storage limit (sufficient for metadata)
- Survives browser restart
- Cleared if user clears browsing data
- Not synced across devices/browsers
- Privacy-friendly (stays local)

---

### 8.2 sessionStorage Usage

**Not Currently Used**

Could be used for:
- Temporary state during multi-step forms
- Caching search results within session
- Storing tab state

---

### 8.3 IndexedDB Usage

**Not Currently Used**

Could be used for:
- Offline caching of group data
- Large data sets (>5MB)
- Structured queries locally

**Decision:** Not needed for V3 scale

---

## 9. Security Considerations

### 9.1 Client-Side Security Measures

**Password Hashing:**
```javascript
async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// Example
"mypassword123" → "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8"
```

**Properties:**
- One-way (cannot reverse)
- Deterministic (same input → same hash)
- 64 hex characters output
- Browser-native (SubtleCrypto API)

**Limitations:**
- No salt (same password always produces same hash)
- Vulnerable to rainbow tables
- No rate limiting
- Acceptable for casual use, not financial/sensitive data

---

### 9.2 Data Privacy

**What's Public:**
- Group document is readable by anyone who knows the code
- Group codes act as passwords (security through obscurity)

**What's Private:**
- Passwords (only hashes stored)
- User's group list (localStorage, not synced)

**What's Shared:**
- All poker night data
- All player data
- All statistics
- Within group members only

**PII Considerations:**
- Player names (first names typically, not full identity)
- No email addresses
- No phone numbers
- No payment information
- No IP addresses logged

---

### 9.3 Potential Security Issues & Mitigations

**Issue: Group Code Enumeration**
- Attacker could try random codes
- **Mitigation:** 8-character codes = 36^7 combinations (78 billion)
- Very low probability of guessing

**Issue: Password Brute Force**
- No rate limiting on password attempts
- **Mitigation:** Client-side only, limited by network speed
- Firebase has some built-in DDoS protection
- Not a high-value target (poker stats, not money)

**Issue: Data Tampering**
- User with admin password can modify anything
- **Mitigation:** Trust model (friends only)
- Can review history via export
- Firebase versioning available for recovery

**Issue: Exposed API Key**
- Firebase API key visible in source code
- **Mitigation:** This is normal and safe for Firebase
- Security enforced by Firestore rules
- API key just identifies project, doesn't grant access

---

## 10. Scalability Analysis

### 10.1 Current Limits

**Per Group:**
- Players: No hard limit (UI tested up to 50)
- Nights: No hard limit (UI tested up to 500)
- Firestore document: 1MB max (groups won't hit this)

**System-Wide:**
- Groups: Unlimited (Firestore scales infinitely)
- Concurrent users: Thousands (Firebase handles)

### 10.2 Performance at Scale

**100 Nights:**
- Load time: < 500ms
- Search: Instant
- Calculations: < 100ms

**500 Nights:**
- Load time: ~1-2s
- Search: < 100ms
- Calculations: ~200ms
- Still acceptable

**1000+ Nights:**
- May need pagination
- Consider archiving old years
- Recommend split into separate groups or archive

---

## 11. Browser API Usage

**APIs Used:**
- SubtleCrypto (password hashing)
- localStorage (group list)
- URLSearchParams (routing)
- Fetch (Firebase SDK uses)
- Canvas (Chart.js uses)

**APIs NOT Used:**
- IndexedDB
- Service Workers (PWA features)
- Web Sockets (Firebase abstracts this)
- Geolocation
- Camera/Microphone
- Bluetooth

---

## 12. Third-Party Dependencies

### 12.1 Firebase SDK

**Version:** 10.8.0  
**Modules Used:**
- firebase-app.js
- firebase-firestore.js

**CDN:**
```
https://www.gstatic.com/firebasejs/10.8.0/
```

**Why This Version:**
- Stable release
- Modular imports
- Tree-shakeable
- Good browser support

### 12.2 Chart.js

**Version:** 3.9.1  
**CDN:**
```html
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
```

**Usage:**
- Bar charts (leaderboard)
- Responsive
- Color-coded data
- No interactivity needed (static display)

**Configuration:**
```javascript
{
  type: 'bar',
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } }
  }
}
```

### 12.3 Google Fonts

**Fonts:**
- Outfit: 400, 500, 600, 700, 800
- Space Mono: 400, 700

**CDN:**
```html
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
```

**Why These Fonts:**
- Outfit: Modern, clean, readable, good number rendering
- Space Mono: Monospace for codes/numbers, retro poker feel

---

**END OF PART 2**

Continue to Part 3 for UI/UX Design System →
