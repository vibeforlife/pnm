# Poker Night Manager - Technical Specification
## Part 1: Project Overview & Core Requirements

**Version:** 3.0 (Locked)  
**Last Updated:** February 3, 2026  
**Document Type:** Complete Technical Specification for Rebuild/Extension  
**Target Audience:** Developers & AI Coding Systems

---

## 1. Executive Summary

### 1.1 Project Vision
Build a modern, mobile-first web application for tracking poker games across friend groups with real-time multi-user collaboration, comprehensive statistics, and gamification elements.

### 1.2 Core Value Propositions
- **Zero Friction:** No accounts required - just group codes
- **Real-time Sync:** Multiple admins edit simultaneously
- **Complete Tracking:** Rebuys, expenses, settlements all automated
- **Engagement:** Achievements, wrapped stats, fortune cookies
- **Beautiful UX:** Glassmorphism design, smooth animations

### 1.3 Technical Approach
- **Pure client-side** JavaScript application
- **Firebase Firestore** for backend-as-a-service
- **No build step** required - runs directly in browser
- **Progressive enhancement** - works offline once loaded

---

## 2. User Personas & Stories

### 2.1 Primary Persona: Game Organizer (Admin)
**Profile:**
- Hosts regular poker nights (weekly/monthly)
- Manages 4-10 players
- Wants to track statistics and settle debts
- Uses mobile device primarily

**User Stories:**
```
As a game organizer,
I want to quickly record game results including rebuys,
So that I can settle debts accurately and track long-term stats.

As a game organizer,
I want to see who owes whom with minimal transactions,
So that settlement is quick and easy.

As a game organizer,
I want to track food/drink expenses,
So that costs are split fairly.

As a game organizer,
I want to search and filter past games,
So that I can find specific nights or analyze trends.
```

### 2.2 Secondary Persona: Regular Player (Viewer)
**Profile:**
- Plays in poker group regularly
- Wants to check stats and rankings
- Doesn't manage the group
- Mobile-first user

**User Stories:**
```
As a player,
I want to view my statistics and ranking,
So that I can track my performance.

As a player,
I want to see who I owe money to,
So that I can settle my debts.

As a player,
I want to see year-end wrapped stats,
So that I can share accomplishments.

As a player,
I want to view achievements I've earned,
So that I feel motivated to play more.
```

---

## 3. System Requirements

### 3.1 Functional Requirements

#### FR-001: Multi-Group Support
**Priority:** P0 (Critical)  
**Description:** Users can create and join multiple poker groups, each with independent data.

**Acceptance Criteria:**
- User can create unlimited groups
- Each group has unique 8-character code (format: XXXX-XXXX)
- User can join multiple groups with different roles (admin in one, viewer in another)
- Group codes can be auto-generated or custom
- No duplicate group codes allowed

**Technical Notes:**
- Group code generation excludes confusing characters (0, O, 1, I, L)
- localStorage tracks user's groups for quick access
- URL parameter passes group context: `?group=CODE`

---

#### FR-002: Role-Based Access Control
**Priority:** P0 (Critical)  
**Description:** Two-tier access system with admin and viewer roles per group.

**Acceptance Criteria:**
- Each group has TWO passwords: admin password + optional viewer password
- Admin password grants full edit access
- Viewer password grants read-only access
- Passwords minimum 6 characters
- SHA-256 one-way encryption for password storage
- No plain-text passwords stored

**Access Matrix:**
| Feature | Admin | Viewer |
|---------|-------|--------|
| Create/Edit/Delete Nights | ✅ | ❌ |
| Add/Edit/Delete Players | ✅ | ❌ |
| Mark Settlements Paid | ✅ | ❌ |
| View All Data | ✅ | ✅ |
| Export/Import | ✅ | ❌ |
| Change Settings | ✅ | ❌ |
| Search/Sort/Filter | ✅ | ✅ |

---

#### FR-003: Poker Night Tracking with Rebuys
**Priority:** P0 (Critical)  
**Description:** Track poker games with support for multiple buy-ins (rebuys/add-ons) per player.

**Acceptance Criteria:**
- Record date, location (optional), notes (optional)
- Track individual player results:
  - Total buy-in (sum of all buy-ins including rebuys)
  - Final cash out amount
  - Calculated net winnings (cash out - total buy-in)
- Display 4-column table: Player | Buy-in | Cash Out | Net
- Live balance validation (total buy-ins = total cash outs)
- Balance indicator: Green when balanced, Red with difference when off
- Updates in real-time as values change

**Example:**
```
Night: Feb 5, 2024 at Bob's House
Standard Buy-in: $20

Player Results:
- Alice: Buy-in $40 (rebought once), Cash Out $70 → Net +$30
- Bob: Buy-in $20, Cash Out $5 → Net -$15
- Charlie: Buy-in $20, Cash Out $5 → Net -$15

Balance Check: ✅ Balanced! Buy-in: $80 = Cash Out: $80
```

**Technical Notes:**
- Default buy-in pre-fills from settings but can be overridden per player
- Net winnings auto-calculated (not user input)
- Validation prevents saving if balance is significantly off (>$0.01)
- Old data without `totalBuyIn` field defaults to night's `buyIn` value

---

#### FR-004: Expense Tracking & Split
**Priority:** P0 (Critical)  
**Description:** Track shared expenses (food, drinks, prizes) and split evenly among players.

**Acceptance Criteria:**
- Add multiple expenses per night
- Each expense records: Who paid, Amount, Description (optional)
- Expenses split evenly among ALL players in that night
- Person who paid gets reimbursed
- Everyone else pays their equal share
- Included in settlement calculations

**Example:**
```
4 players, Alice paid $40 for pizza:
- Alice: +$40 (reimbursed) - $10 (her share) = +$30
- Bob: -$10 (his share)
- Charlie: -$10 (his share)  
- David: -$10 (his share)
```

---

#### FR-005: Settlement Optimization
**Priority:** P0 (Critical)  
**Description:** Calculate minimum number of transactions to settle all debts.

**Acceptance Criteria:**
- Per-night settlement shows 3 columns:
  1. 🃏 Poker (Orange) - poker winnings only
  2. 💰 Expenses (Green) - expense reimbursements only
  3. 📊 Optimized (Purple) - combined & minimized transactions
- Global settlement includes expenses from all nights
- Optimization algorithm reduces transaction count
- Example: A→B $20, B→C $20 optimizes to A→C $20 (1 transaction instead of 2)
- Settlement tracking: Mark individual transactions as paid
- Paid transactions show in green, unpaid in red
- "Unsettled Only" view filters to show only unpaid debts

**Mathematical Properties:**
- Optimized result is mathematically equivalent to separate poker + expense settlements
- Minimizes total number of payments
- No transaction loops (A→B→C→A becomes direct paths)

---

#### FR-006: Player Management
**Priority:** P0 (Critical)  
**Description:** Manage player roster with full CRUD operations.

**Acceptance Criteria:**
- Add player: Name only (unique within group)
- Edit player: Rename (updates everywhere including all historical games)
- Delete player: Remove from roster and all games (with confirmation)
- Track date player was added to group
- Display join date on player cards ("Joined: Feb 2024")
- Search players by name (real-time filtering)
- Sort players by: Winnings / A-Z / Z-A / Games / Wins / Win Rate

**Data Tracking:**
```javascript
playerInfo: {
  "Alice": {
    "dateAdded": "2024-02-01T15:30:00Z"
  }
}
```

**Edge Cases:**
- Editing player name updates all references in poker nights
- Deleting player removes from all historical games
- Cannot delete player who doesn't exist
- Cannot create duplicate player names

---

#### FR-007: Statistics & Leaderboards
**Priority:** P1 (High)  
**Description:** Comprehensive statistics with year filtering and visualizations.

**Components:**

**Dashboard Stats (4 Cards):**
- Total Nights: Count of all games
- Total Players: Count of unique players
- Total Pot: Sum of all buy-ins (actual chips on table, not money changed hands)
- Avg/Night: Total pot ÷ number of nights

**Leaderboard:**
- Bar chart (Chart.js) showing top 10 players
- Complete rankings list (all players)
- Medals for top 3 (🥇🥈🥉)
- Shows: Games played, Wins, Win rate, Total winnings
- Color-coded winnings (green positive, red negative)
- **Year filter:** YTD / Lifetime / 2026 / 2025 / 2024...

**Lifetime Stats:**
- Total games, players, money moved
- Biggest single win (player + amount)
- Biggest single loss (player + amount)

**Calculation Notes:**
- Default to current year (YTD)
- Year filter affects all calculations
- Player must have played at least 1 game in period to appear

---

#### FR-008: Search & Filter Capabilities
**Priority:** P1 (High)  
**Description:** Robust search and sort across all data tables.

**Poker Nights Search:**
- Search by: Date (any format), Location name
- Real-time filtering (updates as you type)
- Case-insensitive matching
- Partial matches supported

**Poker Nights Sort Options:**
1. Newest First (default)
2. Oldest First
3. Pot Size (High to Low)
4. Pot Size (Low to High)
5. Location (A-Z)
6. Winner (A-Z)

**Players Search:**
- Search by: Player name
- Real-time filtering
- Case-insensitive
- Partial matches

**Players Sort Options:**
1. Total Winnings (High to Low) - default
2. Name (A-Z)
3. Name (Z-A)
4. Games Played (High to Low)
5. Wins (High to Low)
6. Win Rate (High to Low)

**Empty States:**
- When search returns no results: "No nights match your search" 🔍
- When no data exists: "No poker nights yet" with Add button (admin only)

---

#### FR-009: Achievement System
**Priority:** P1 (High)  
**Description:** Gamification through 20+ achievement types with smart filtering.

**Achievement Categories:**

**Milestone:**
- 🎯 Welcome to Club: Play 1st game

**Experience:**
- 🎲 Veteran Player: 10+ games
- ⭐ Dedication: 50+ games

**Skill:**
- 🏆 High Roller: 60%+ win rate (min 5 games)

**Streak:**
- 🔥 Hot Streak: 3+ consecutive wins

**Money:**
- 💰 Big Winner: Single win of $100+
- 💎 Profit Master: $500+ total winnings

**Dominance:**
- 💀 Grim Reaper: Eliminate 3+ players in one night

**Consistency:**
- 🔒 Fortress: 5+ consecutive games without going bust
- 🏦 Bankroll Builder: 3+ consecutive months with positive winnings

**Anniversary (10 badges):**
- 🎂 1-10 Year Anniversaries: Years since joining group

**Achievement Filters:**
- Year filter: YTD / Lifetime / Specific years
- Player filter: All / Individual player
- Badge filter: All / Specific achievement type

**Display:**
- Badge icon (emoji)
- Achievement name
- Player name (colored cyan)
- Description with details
- Date earned or "Season" for ongoing
- Special golden styling for anniversaries

---

#### FR-010: Wrapped Feature
**Priority:** P2 (Medium)  
**Description:** Year-end review with personalized statistics and interactive fortune cookies.

**Controls:**
- Period selector: Year to Date / Lifetime
- Player selector: All Players / Individual player

**Per-Player Display (Gradient Card):**

**Stats Grid (2x2, Huge Numbers):**
- Games Played
- Total Winnings/Losses
- Win Rate %
- Ranking #

**Highlights Section (6 Items):**
- 🎯 Biggest Win: $XXX.XX
- 📉 Biggest Loss: $XXX.XX
- 🔥 Best Streak: +X wins
- 🎮 Favorite Opponent: [Name]
- 📅 Best Month: [Month Year] ($XXX)
- 💰 Average per Game: $XXX

**Achievements Section:**
- White pill badges
- Shows all achievements earned in period

**Fortune Cookie (Interactive):**
- Initial: Large 🥠 with "Click to open your fortune"
- Animation sequence:
  1. Click → Shake (0.5s, -10° to +10° rotation)
  2. Break (0.5s, scale 1.5x, rotate 20°, fade out)
  3. Reveal (0.8s, fortune fades in, scales up, slides up)
- Final: ✨ + Random fortune + "— Ancient Poker Wisdom" + ♠ ♥ ♦ ♣
- 100 unique poker-themed fortune sayings
- Not clickable after opening

**Visual Design:**
- Orange to red gradient background
- Dark overlay cards for stats
- White semi-transparent achievement pills
- Golden dashed border for fortune cookie
- Responsive (single column on mobile)

---

#### FR-011: Real-Time Synchronization
**Priority:** P0 (Critical)  
**Description:** All users see updates instantly via Firebase real-time listeners.

**Behavior:**
- Admin A adds player → Admin B sees it immediately (no refresh)
- Admin edits night → Viewers see update in real-time
- Multiple admins can edit simultaneously
- Last-write-wins for conflicts
- onSnapshot listener updates UI automatically

**Implementation Pattern:**
```javascript
const groupRef = firestore.doc(db, 'groups', groupId);
firestore.onSnapshot(groupRef, (doc) => {
  if (doc.exists()) {
    groupData = doc.data();
    updateUI();  // Refresh current tab
  }
});
```

---

## 4. User Flows

### 4.1 First-Time User: Create Group

```
1. User opens index.html
2. Sees: Logo, "Create New Group", "Join Existing Group"
3. Clicks "Create New Group"
4. Modal opens with form:
   - Group Name: [input]
   - Group Code: [optional input or auto-generate]
   - Admin Password: [password input, min 6 chars]
   - Viewer Password: [optional password input]
5. Clicks "Create Group"
6. System:
   - Validates inputs
   - Generates code if not provided
   - Checks Firebase for duplicate code
   - Hashes passwords with SHA-256
   - Creates group document in Firestore
   - Saves to localStorage
7. Success screen shows:
   - ✅ Group Created!
   - Group code in large font
   - "Share this code with friends"
   - [Enter Group] button
8. Clicks "Enter Group"
9. Redirects to admin.html?group=CODE
```

### 4.2 Returning User: Join Group

```
1. User opens index.html
2. Clicks "Join Existing Group"
3. Enters:
   - Group Code: POKER-TEST
   - Password: ******
4. Clicks "Join Group"
5. System:
   - Fetches group from Firestore by code
   - Hashes entered password
   - Compares with adminPasswordHash
   - If match → role = "admin"
   - If not, compares with viewerPasswordHash
   - If match → role = "viewer"
   - If neither → Error: "Invalid password"
6. On success:
   - Saves to localStorage
   - Redirects to admin.html (if admin) or viewer.html (if viewer)
   - Appends ?group=CODE to URL
```

### 4.3 Admin: Add Poker Night with Rebuys

```
1. Admin opens admin.html
2. Clicks "🎲 Poker Nights" tab
3. Clicks "➕ Add Night" button
4. Modal opens with:
   - Date: [pre-filled with today]
   - Location: [optional]
   - Buy-in Amount: [pre-filled from settings]
   - Player Results: [auto-populated with all players]
   - Expenses: [empty, can add]
   - Notes: [optional]
5. Admin edits player results:
   - Alice: Buy-in $40 (she rebought), Cash Out $70
   - Bob: Buy-in $20, Cash Out $5
   - Charlie: Buy-in $20, Cash Out $5
6. Balance check shows:
   - ✅ Balanced! Buy-in: $80.00 = Cash Out: $80.00
7. Admin adds expense:
   - Who Paid: Alice
   - Amount: $30
   - Description: Pizza
8. Clicks "💰 Calculate Settlement"
9. Modal shows 3 columns:
   - Poker settlements
   - Expense settlements  
   - Optimized combined (7 payments → fewer)
10. Closes settlement modal
11. Clicks "Save Night"
12. System:
    - Validates date is present
    - Calculates winnings (cashOut - totalBuyIn)
    - Saves to Firestore
    - Shows toast: "Poker night added!"
    - Switches to Nights tab
    - Night appears immediately
```

### 4.4 Viewer: Check Stats

```
1. Viewer opens viewer.html (logged in with viewer password)
2. Sees all tabs but no edit buttons
3. Clicks "🏆 Leaderboard" tab
4. Selects "2024" from year dropdown
5. Sees 2024 rankings with chart
6. Clicks "🎁 Wrapped" tab
7. Redirects to wrapped.html?source=viewer&group=CODE
8. Selects "Lifetime" period
9. Sees all-time stats with fortune cookie
10. Clicks fortune cookie → Animation plays → Fortune revealed
11. Clicks ← back button
12. Returns to viewer.html (not admin.html!)
```

---

## 5. Core Features Deep Dive

### 5.1 Live Balance Check

**Purpose:** Prevent data entry errors when recording game results.

**Location:** Add/Edit Night modal, below Player Results section

**Logic:**
```
For each player row:
  totalBuyIn += player's buy-in input
  totalCashOut += player's cash out input

difference = totalCashOut - totalBuyIn

if (|difference| < 0.01):
  Display: ✅ Balanced! Buy-in: $X.XX = Cash Out: $X.XX
  Style: Green background, green border, green text
else:
  Display: ⚠️ Off by ±$X.XX
          Buy-in: $X.XX • Cash Out: $X.XX
  Style: Red background, red border, red text
```

**Triggers:**
- oninput event on any buy-in field
- oninput event on any cash out field
- onchange event on player dropdown
- onclick event on remove player button (×)
- When modal opens (initial display)

**Visual Specs:**
```css
/* Balanced state */
background: rgba(16, 185, 129, 0.2);
border: 2px solid #10b981;
color: #10b981;

/* Unbalanced state */
background: rgba(239, 68, 68, 0.2);
border: 2px solid #ef4444;
color: #ef4444;
```

---

### 5.2 Three-Column Settlement Display

**Purpose:** Show breakdown of poker vs expenses vs optimized payments.

**Trigger:** "💰 Calculate Settlement" button in Add/Edit Night modal

**Layout:**
```
┌─────────────────────────────────────────────────────────┐
│          💰 Settlement Calculator                        │
│                                                          │
│  Total Pot: $80.00    Expenses: $30.00 total           │
│                                                          │
│ ┌────────┬────────────┬─────────────────────┐          │
│ │ 🃏     │ 💰         │ 📊 Optimized        │          │
│ │ Poker  │ Expenses   │ ⭐                 │          │
│ ├────────┼────────────┼─────────────────────┤          │
│ │Orange  │Green cards │Purple bordered box  │          │
│ │cards   │            │                     │          │
│ │        │Total: $30  │✨ Reduced to X      │          │
│ │Bob→    │            │  payments           │          │
│ │Alice   │Nish→       │                     │          │
│ │$15     │Ammar       │Abbas→Ammar          │          │
│ │        │$15         │$35                  │          │
│ └────────┴────────────┴─────────────────────┘          │
│                                                          │
│  💡 How it works: [Explanation text]                    │
│                                                          │
│                    [Close Button]                        │
└─────────────────────────────────────────────────────────┘
```

**Column Colors:**
- Poker: #f39c12 (orange)
- Expenses: #2ecc71 (green)
- Optimized: #9b59b6 (purple) with 2px border

**Grid Layout:**
```css
display: grid;
grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
gap: 15px;
```

**Transaction Card Format:**
```
┌──────────────┐
│ Alice →      │  (name, bold)
│ Bob          │  (recipient, secondary color)
│ $25.00       │  (amount, large, colored)
└──────────────┘
```

---

### 5.3 Search Implementation Pattern

**HTML Structure:**
```html
<input type="text" 
       class="form-input" 
       id="nightsSearch" 
       placeholder="🔍 Search by date or location..." 
       oninput="loadNights()">
```

**JavaScript Filter Logic:**
```javascript
const searchTerm = document.getElementById('nightsSearch')?.value.toLowerCase() || '';

if (searchTerm) {
  nights = nights.filter(night => {
    const dateMatch = night.date.includes(searchTerm) || 
                     formatDate(night.date).toLowerCase().includes(searchTerm);
    const locationMatch = (night.location || '').toLowerCase().includes(searchTerm);
    return dateMatch || locationMatch;
  });
}
```

**UX Details:**
- Real-time (no search button needed)
- Debouncing not required (small datasets)
- Empty state when no results
- Search persists until cleared
- Case-insensitive for user convenience

---

### 5.4 Sort Implementation Pattern

**HTML Structure:**
```html
<select class="form-select" id="nightsSort" onchange="loadNights()">
  <option value="newest">Newest First</option>
  <option value="oldest">Oldest First</option>
  <option value="pot-high">Pot Size (High-Low)</option>
  <option value="pot-low">Pot Size (Low-High)</option>
  <option value="location">Location (A-Z)</option>
  <option value="winner">Winner (A-Z)</option>
</select>
```

**JavaScript Sort Logic:**
```javascript
const sortBy = document.getElementById('nightsSort')?.value || 'newest';

if (sortBy === 'newest') {
  nights.sort((a, b) => b.date.localeCompare(a.date));
} else if (sortBy === 'pot-high') {
  nights.sort((a, b) => {
    const potA = a.results.reduce((sum, r) => sum + (r.totalBuyIn || a.buyIn), 0);
    const potB = b.results.reduce((sum, r) => sum + (r.totalBuyIn || b.buyIn), 0);
    return potB - potA;
  });
}
// ... etc
```

---

## 6. Non-Functional Requirements

### 6.1 Performance
- **Initial Load:** < 2 seconds on 4G
- **Data Save:** < 500ms to Firebase
- **UI Updates:** < 100ms after data change
- **Search/Filter:** Instant (< 50ms)
- **Chart Render:** < 300ms

**Optimization Strategies:**
- Lazy load charts (only when tab visible)
- Destroy charts before recreating (prevent memory leaks)
- Batch UI updates (don't update individual elements)
- Use CSS transforms for animations (GPU accelerated)

### 6.2 Browser Compatibility
**Minimum Requirements:**
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

**Features Used:**
- ES6+ JavaScript (arrow functions, template literals, async/await)
- CSS Grid & Flexbox
- Web Crypto API (SHA-256)
- ES6 Modules
- Optional chaining (?.)

**No Support Needed:**
- Internet Explorer
- Legacy browsers

### 6.3 Mobile Responsiveness
**Breakpoints:**
```css
/* Mobile First: Default styles for < 480px */

/* Tablet: 480px - 768px */
@media (max-width: 768px) {
  .stats-grid { grid-template-columns: repeat(2, 1fr); }
}

/* Desktop: > 768px */
/* Enhanced layouts */
```

**Mobile Optimizations:**
- Touch targets minimum 44px × 44px
- Swipeable tabs (overflow-x: auto)
- Responsive tables (horizontal scroll)
- Large readable fonts (min 14px body)
- One-handed operation friendly
- Bottom navigation consideration

### 6.4 Accessibility
**Implemented:**
- Semantic HTML5 (header, nav, main, section)
- ARIA labels on icon-only buttons (title attribute)
- Keyboard navigation (tab order)
- Focus states on interactive elements
- Color contrast WCAG AA compliant (4.5:1 minimum)
- Form labels properly associated

**Future Enhancements:**
- Screen reader announcements for dynamic updates
- Skip to content link
- Keyboard shortcuts (? for help)
- High contrast mode toggle

### 6.5 Data Constraints
**Firebase Firestore Limits:**
- Document size: 1MB max (realistically groups won't hit this)
- Queries: Free tier = 50,000 reads/day, 20,000 writes/day
- Sufficient for 100+ active groups

**Application Limits:**
- No hard limit on players per group
- No hard limit on poker nights
- Practical limit: ~1000 nights before performance degrades
- Consider archiving after 2-3 years

**Field Constraints:**
- Group name: 30 characters max
- Player name: Reasonable (no hard limit, recommend 20)
- Location: Reasonable (no hard limit)
- Notes: Reasonable (suggest 500 char limit)
- Currency symbol: 3 characters max

---

## 7. Success Metrics

### 7.1 Technical Metrics
- **Uptime:** 99.9% (Firebase SLA)
- **Data Loss:** 0% (Firebase guarantees)
- **Error Rate:** < 0.1% of operations
- **Load Time:** < 2s on 4G

### 7.2 User Engagement Metrics
- **Active Groups:** Groups with game added in last 30 days
- **Retention:** Users returning after 7 days
- **Feature Adoption:** % using wrapped, achievements
- **Mobile Usage:** % of traffic from mobile devices

### 7.3 Data Quality Metrics
- **Balance Accuracy:** % of nights with balanced cash flows
- **Settlement Completion:** % of debts marked as paid
- **Data Completeness:** % of nights with location, notes

---

## 8. User Interface Principles

### 8.1 Design Philosophy
**"Glassmorphism meets Poker Aesthetics"**
- Frosted glass effects (backdrop-filter: blur)
- Semi-transparent layers
- Deep blue/purple gradients
- Cyan and purple accents
- Poker-themed decorations (card suits, chips)
- Smooth, premium feel

### 8.2 Interaction Patterns
**Immediate Feedback:**
- Button ripple effects on click
- Hover states on all interactive elements
- Loading spinners during async operations
- Toast notifications for actions
- Color changes for state (red/green balance check)

**Progressive Disclosure:**
- Modals for complex forms
- Tabs for feature organization
- Expandable sections where appropriate
- Search/filter collapse results, don't hide UI

**Error Prevention:**
- Confirmation dialogs for destructive actions
- Live validation (balance check)
- Helpful placeholders and hints
- Disabled states when action unavailable

---

## 9. Technical Constraints & Decisions

### 9.1 Why No Backend Server?
**Decision:** Use Firebase Firestore instead of custom backend

**Rationale:**
- Faster development (no server code)
- Free tier sufficient for most users
- Built-in real-time sync
- Automatic scaling
- No server maintenance
- Security via Firestore rules

**Trade-offs:**
- Less control over data access
- Public API keys (acceptable for Firebase)
- Limited to Firestore query capabilities
- Vendor lock-in to Firebase

### 9.2 Why No Framework (React/Vue)?
**Decision:** Vanilla JavaScript

**Rationale:**
- No build step needed
- Smaller bundle size
- Faster load time
- Easier for beginners to understand
- No framework updates/breaking changes
- Direct DOM manipulation is fast for this scale

**Trade-offs:**
- More verbose code
- Manual state management
- No component reusability
- Harder to scale to very large apps

### 9.3 Why Client-Side Password Hashing?
**Decision:** SHA-256 hash in browser before comparing

**Rationale:**
- No authentication backend needed
- Passwords never sent to server in plain text
- Good enough for friend groups (not banking app)
- Simple implementation

**Trade-offs:**
- No salt means rainbow table attacks possible
- No rate limiting on password attempts
- Not enterprise-grade security
- Acceptable for use case (casual games with friends)

### 9.4 Why localStorage for Group List?
**Decision:** Store user's group memberships in browser localStorage

**Rationale:**
- No user accounts needed
- Fast access to "My Groups"
- Works offline
- Private to that browser

**Trade-offs:**
- Not synced across devices
- Cleared if user clears browser data
- User must rejoin on new device
- Acceptable since group codes are shareable

---

## 10. Out of Scope (Explicitly NOT Included)

### Not in V3:
❌ User authentication (email/password login)  
❌ User profiles with avatars  
❌ Venmo/PayPal payment integration  
❌ Push notifications  
❌ Photo uploads  
❌ Chat/messaging between players  
❌ Tournament brackets  
❌ Configurable achievement thresholds  
❌ Custom achievement creation  
❌ Email notifications  
❌ Calendar integration  
❌ Multi-currency support  
❌ Tax reporting  
❌ Hand history tracking  
❌ Video recording integration  
❌ Social media sharing (direct integration)  
❌ Analytics dashboard for admins  
❌ A/B testing framework  
❌ Internationalization (i18n)  

**Rationale:** These would add complexity without proportional value for the core use case of tracking casual poker games among friends.

---

## 11. Future Roadmap (Post-V3)

### V4 Potential Features:
- **Photo Gallery:** Upload photos per night
- **Advanced Analytics:** Trends, head-to-head records, profit curves
- **Custom Achievements:** Admins define their own badges
- **Tournament Mode:** Bracket system, prize pools
- **Payment Integration:** Venmo/PayPal quick pay links
- **Notifications:** Remind players of upcoming games
- **Player Profiles:** Avatars, bios, preferences
- **Export Options:** PDF reports, CSV downloads
- **Themes:** Dark/light mode, custom color schemes
- **Multi-language:** Spanish, French, etc.

---

## 12. Glossary

**Admin:** User with full edit access to a group  
**Viewer:** User with read-only access to a group  
**Group:** A collection of players and poker nights  
**Group Code:** 8-character identifier for a group (e.g., POKER-X7Y2)  
**Buy-in:** Amount a player pays to enter the game  
**Rebuy:** Additional buy-in during the same game  
**Cash Out:** Amount a player receives when leaving the game  
**Net Winnings:** Cash out minus total buy-in  
**Total Pot:** Sum of all buy-ins (actual chips on table)  
**Settlement:** List of payments to balance all debts  
**Optimization:** Reducing number of transactions needed  
**YTD:** Year to Date (current year only)  
**Wrapped:** Year-end review feature with personalized stats  
**Achievement:** Badge earned for reaching milestone  
**Fortune Cookie:** Interactive element revealing random poker wisdom  

---

## 13. Document Map

This specification is split into multiple parts:

**Part 1 (This Document):** Project Overview & Core Requirements  
**Part 2:** Technical Architecture & Data Model  
**Part 3:** UI/UX Design System & Components  
**Part 4:** Feature Specifications (Detailed)  
**Part 5:** Algorithms & Calculations  
**Part 6:** Firebase Integration & Patterns  
**Part 7:** Testing & Quality Assurance  
**Part 8:** Deployment & Operations  

---

**END OF PART 1**

Continue to Part 2 for Technical Architecture & Data Model →
