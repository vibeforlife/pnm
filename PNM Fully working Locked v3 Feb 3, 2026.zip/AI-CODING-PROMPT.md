# AI Coding Prompt: Poker Night Manager V3

**Target:** AI coding assistants (Cursor, Windsurf, Claude Code, GitHub Copilot, etc.)  
**Purpose:** Complete rebuild specification in prompt-optimized format  
**Output:** 5 HTML files + 1 Firebase rules file

---

## SYSTEM PROMPT

You are building a modern web application for tracking poker games. Create a mobile-first, glassmorphism-themed app with Firebase backend.

**Technology Stack:**
- Pure HTML5/CSS3/JavaScript (ES6+)
- Firebase Firestore for backend
- Chart.js 3.9.1 for visualizations
- No frameworks, no build tools
- Google Fonts: Outfit + Space Mono

**Core Architecture:**
- Client-side only (no backend server)
- Real-time multi-user sync via Firebase
- Role-based access (admin/viewer)
- Group code authentication (SHA-256 hashing)

---

## FILES TO CREATE

### 1. index.html
Landing page with group creation/joining

### 2. admin.html  
Full-featured admin interface (8 tabs)

### 3. viewer.html
Read-only viewer (same features, no edit/delete)

### 4. wrapped.html
Year-end review with fortune cookies

### 5. achievements-enhanced.html
Achievement system with 20+ badge types

### 6. firestore.rules
Firebase security configuration

---

## DESIGN SYSTEM

### Colors (CSS Variables)
```css
:root {
  --primary-dark: #0a0e27;
  --primary-blue: #1a1f4d;
  --accent-purple: #6366f1;
  --accent-cyan: #06b6d4;
  --glass-bg: rgba(255, 255, 255, 0.05);
  --glass-border: rgba(255, 255, 255, 0.1);
  --text-primary: #f8fafc;
  --text-secondary: #cbd5e1;
  --success: #10b981;
  --error: #ef4444;
}
```

### Typography
- Primary: 'Outfit' (400, 500, 600, 700, 800)
- Monospace: 'Space Mono' (400, 700)
- Base size: 14-16px
- Headings: 24-32px
- Stats: 28px-4em

### Visual Style
- **Glassmorphism:** backdrop-filter: blur(10px), semi-transparent backgrounds
- **Dark theme:** Deep blue gradient background
- **Animations:** 0.3s transitions, smooth hover effects
- **Poker theme:** Card suits (♠♥♦♣), floating chips, orange/green accents

---

## FIREBASE CONFIGURATION

### Config Object
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyDRFKc8fr96RNryd9r7OOco-xoQlf_ZcFg",
  authDomain: "pnm-fx2.firebaseapp.com",
  projectId: "pnm-fx2",
  storageBucket: "pnm-fx2.firebasestorage.app",
  messagingSenderId: "186393450910",
  appId: "1:186393450910:web:1acfae1bee6e46b718de8f"
};
```

### SDK Setup Pattern
```javascript
// ES6 module
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getFirestore, doc, getDoc, updateDoc, onSnapshot } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

window.db = db;
window.firestore = { doc, getDoc, updateDoc, onSnapshot };
window.firebaseReady = true;
```

### Security Rules (firestore.rules)
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /groups/{groupId} {
      allow read: if true;
      allow create: if true;
      allow update: if true;
      allow delete: if false;
    }
  }
}
```

---

## DATA MODEL

### Firestore Document Schema
```javascript
{
  // Metadata
  "id": "POKER-X7Y2",                    // 8-char code (XXXX-XXXX format)
  "name": "Friday Night Poker",
  "createdAt": "2024-02-01T10:00:00Z",
  "currentYear": 2024,
  
  // Auth (SHA-256 hashes)
  "adminPasswordHash": "5e884898...",
  "viewerPasswordHash": "6b86b273...",   // Optional
  
  // Players
  "players": ["Alice", "Bob", "Charlie"],
  
  "playerInfo": {
    "Alice": { "dateAdded": "2024-02-01T15:30:00Z" },
    "Bob": { "dateAdded": "2024-02-01T15:31:00Z" }
  },
  
  // Poker Nights
  "nights": [
    {
      "date": "2024-02-05",              // YYYY-MM-DD
      "location": "Bob's House",          // Optional
      "buyIn": 20,                        // Standard buy-in
      "notes": "Epic game!",              // Optional
      "settled": false,                   // Settlement tracking
      
      "results": [
        {
          "player": "Alice",
          "totalBuyIn": 40,               // Includes rebuys
          "cashOut": 70,
          "winnings": 30                  // cashOut - totalBuyIn
        }
      ],
      
      "expenses": [
        {
          "paidBy": "Alice",
          "amount": 30,
          "description": "Pizza"          // Optional
        }
      ]
    }
  ],
  
  // Settlement Tracking
  "settledTransactions": [
    {
      "from": "Bob",
      "to": "Alice",
      "amount": 25.00,
      "settledDate": "2024-02-05T22:30:00Z"
    }
  ],
  
  // Settings
  "settings": {
    "currency": "$",
    "defaultBuyIn": 20
  },
  
  "archivedYears": {}                    // Reserved
}
```

### localStorage Schema
```javascript
// Key: "userGroups"
[
  {
    "groupId": "POKER-X7Y2",
    "groupName": "Friday Night Poker",
    "role": "admin",  // or "viewer"
    "lastAccessed": "2024-02-05T15:30:00Z"
  }
]
```

---

## FILE 1: index.html

### Purpose
Landing page for creating/joining groups

### Key Features

**1. Logo Section**
- Large ♠♥ icon (gradient cyan→purple)
- "Poker Night Manager" title (32px, extrabold, gradient)
- "Track • Compete • Dominate" tagline

**2. Main Actions**
- "🎲 Create New Group" button → Opens create modal
- "🔑 Join Existing Group" button → Opens join modal

**3. My Groups List**
- Shows all groups from localStorage
- Sorted by lastAccessed (recent first)
- Each card shows: name, role badge (👑 Admin / 👁️ Viewer)
- Click → Opens admin.html or viewer.html

### Create Group Modal

**Form Fields:**
- Group Name (required, max 30 chars)
- Group Code (optional, auto-generate if empty)
- Admin Password (required, min 6 chars)
- Viewer Password (optional, min 6 chars)

**Process:**
```javascript
1. Validate inputs
2. Generate code: 
   - Format: XXXX-XXXX
   - Chars: A-Z (no O), 2-9 (no 0,1)
   - Check Firebase for duplicates
3. Hash passwords using SHA-256:
   async function hashPassword(password) {
     const data = new TextEncoder().encode(password);
     const hash = await crypto.subtle.digest('SHA-256', data);
     return Array.from(new Uint8Array(hash))
       .map(b => b.toString(16).padStart(2, '0')).join('');
   }
4. Create Firestore document:
   await firestore.updateDoc(firestore.doc(db, 'groups', code), groupData);
5. Save to localStorage:
   userGroups.push({ groupId, groupName, role: 'admin', lastAccessed: now });
6. Show success screen with group code (large, monospace, cyan)
7. "Enter Group" button → admin.html?group=CODE
```

### Join Group Modal

**Form Fields:**
- Group Code (required)
- Password (required, min 6 chars)

**Process:**
```javascript
1. Fetch group: await firestore.getDoc(firestore.doc(db, 'groups', code))
2. Hash entered password
3. Compare with adminPasswordHash
4. If match → role = 'admin'
5. Else compare with viewerPasswordHash
6. If match → role = 'viewer'
7. Else → Error: "Invalid password"
8. Save to localStorage
9. Redirect to admin.html or viewer.html with ?group=CODE
```

---

## FILE 2: admin.html

### Structure
- Sticky header (logo, group name/code, home/settings buttons)
- 8 tab navigation (horizontal scroll on mobile)
- Tab content area
- Modals (Add Night, Add Player, Settlement, Settings)
- Toast notification
- Background decorations (poker chips, card suits)

### Tab 1: Dashboard

**4 Stats Cards (2x2 grid):**
```javascript
// Total Nights
nights.length

// Total Players  
players.length

// Total Pot (sum of all buy-ins, NOT money changed hands)
nights.reduce((sum, night) => {
  const nightPot = night.results.reduce((s, r) => {
    const buyIn = r.totalBuyIn !== undefined ? r.totalBuyIn : night.buyIn;
    return s + buyIn;
  }, 0);
  return sum + nightPot;
}, 0)

// Avg/Night
totalPot / nights.length
```

**Recent 5 Nights (Clickable Cards):**
- Display: Date, Location, Player count, Buy-in
- Click → Opens edit modal for that night
- Sorted newest first

**Top 5 Players (Clickable Cards):**
- Display: Rank, Name, Games, Win rate, Total winnings
- Color-coded winnings (green/red)
- Click → Goes to Leaderboard tab

### Tab 2: Poker Nights

**Search & Sort Controls:**
```html
<input id="nightsSearch" placeholder="🔍 Search by date or location..." oninput="loadNights()">
<select id="nightsSort" onchange="loadNights()">
  <option value="newest">Newest First</option>
  <option value="oldest">Oldest First</option>
  <option value="pot-high">Pot Size (High-Low)</option>
  <option value="pot-low">Pot Size (Low-High)</option>
  <option value="location">Location (A-Z)</option>
  <option value="winner">Winner (A-Z)</option>
</select>
```

**Search Logic:**
```javascript
const searchTerm = document.getElementById('nightsSearch').value.toLowerCase();
nights = nights.filter(night => {
  const dateMatch = night.date.includes(searchTerm) || 
                   formatDate(night.date).toLowerCase().includes(searchTerm);
  const locationMatch = (night.location || '').toLowerCase().includes(searchTerm);
  return dateMatch || locationMatch;
});
```

**Sort Logic:**
```javascript
if (sortBy === 'newest') {
  nights.sort((a, b) => b.date.localeCompare(a.date));
} else if (sortBy === 'pot-high') {
  nights.sort((a, b) => {
    const potA = a.results.reduce((sum, r) => sum + (r.totalBuyIn || a.buyIn), 0);
    const potB = b.results.reduce((sum, r) => sum + (r.totalBuyIn || b.buyIn), 0);
    return potB - potA;
  });
}
// ... other sorts
```

**Night Card Display:**
- Date (title, formatted: "Feb 5, 2024")
- Location + Buy-in (subtitle)
- Winner highlight (if has results)
- 4-column table: Player | Buy-in | Cash Out | Net
- Expenses section (if present)
- Notes (if present)
- Edit (✏️) and Delete (🗑️) buttons

**Add/Edit Night Modal:**

**Fields:**
```html
<input type="date" id="nightDate" value="[today]">
<input type="text" id="nightLocation" placeholder="John's House">
<input type="number" id="nightBuyIn" value="20" min="1" step="0.01">

<!-- Player Results (dynamic) -->
<div id="nightPlayersContainer">
  <div class="player-result">
    <select><!-- Player dropdown --></select>
    <input placeholder="Buy-in" value="20" oninput="updateBalanceCheck()">
    <input placeholder="Cash Out" oninput="updateBalanceCheck()">
    <button onclick="this.parentElement.remove(); updateBalanceCheck();">×</button>
  </div>
</div>
<button onclick="addPlayerResult()">➕ Add Player</button>

<!-- Live Balance Check -->
<div id="balanceCheck" style="display:none;">
  <div>Balance Check</div>
  <div id="balanceAmount"></div>
</div>

<!-- Expenses (dynamic) -->
<div id="nightExpensesContainer"></div>
<button onclick="addExpense()">➕ Add Expense</button>

<textarea id="nightNotes" placeholder="Notes..."></textarea>
```

**Live Balance Check (CRITICAL FEATURE):**
```javascript
function updateBalanceCheck() {
  let totalBuyIn = 0, totalCashOut = 0;
  
  document.querySelectorAll('#nightPlayersContainer .player-result').forEach(div => {
    const inputs = div.querySelectorAll('input');
    totalBuyIn += parseFloat(inputs[0].value) || 0;
    totalCashOut += parseFloat(inputs[1].value) || 0;
  });
  
  const difference = totalCashOut - totalBuyIn;
  const isBalanced = Math.abs(difference) < 0.01;
  
  balanceCheck.style.display = 'block';
  
  if (isBalanced) {
    // Green styling
    balanceCheck.style.background = 'rgba(16, 185, 129, 0.2)';
    balanceCheck.style.border = '2px solid #10b981';
    balanceCheck.style.color = '#10b981';
    balanceAmount.innerHTML = `✅ Balanced! Buy-in: $${totalBuyIn.toFixed(2)} = Cash Out: $${totalCashOut.toFixed(2)}`;
  } else {
    // Red styling
    balanceCheck.style.background = 'rgba(239, 68, 68, 0.2)';
    balanceCheck.style.border = '2px solid #ef4444';
    balanceCheck.style.color = '#ef4444';
    balanceAmount.innerHTML = `⚠️ Off by ${difference > 0 ? '+' : ''}$${Math.abs(difference).toFixed(2)}<br><small>Buy-in: $${totalBuyIn.toFixed(2)} • Cash Out: $${totalCashOut.toFixed(2)}</small>`;
  }
}

// Trigger on every input change
<input oninput="updateBalanceCheck()">
```

**"💰 Calculate Settlement" Button:**
Opens modal showing 3 columns (see Settlement Algorithm section)

**Save Night:**
```javascript
async function saveNight() {
  const nightData = {
    date: document.getElementById('nightDate').value,
    location: document.getElementById('nightLocation').value,
    buyIn: parseFloat(document.getElementById('nightBuyIn').value),
    notes: document.getElementById('nightNotes').value,
    settled: false,
    results: [],
    expenses: []
  };
  
  // Collect player results
  document.querySelectorAll('#nightPlayersContainer .player-result').forEach(div => {
    const player = div.querySelector('select').value;
    const inputs = div.querySelectorAll('input');
    const totalBuyIn = parseFloat(inputs[0].value) || 0;
    const cashOut = parseFloat(inputs[1].value) || 0;
    const winnings = cashOut - totalBuyIn;
    
    if (player) {
      nightData.results.push({ player, totalBuyIn, cashOut, winnings });
    }
  });
  
  // Collect expenses
  document.querySelectorAll('#nightExpensesContainer .player-result').forEach(div => {
    const paidBy = div.querySelector('select').value;
    const inputs = div.querySelectorAll('input');
    const amount = parseFloat(inputs[0].value) || 0;
    const description = inputs[1].value.trim();
    
    if (paidBy && amount > 0) {
      nightData.expenses.push({ paidBy, amount, description });
    }
  });
  
  // Add or update
  const editIndex = modal.dataset.editIndex;
  if (editIndex) {
    groupData.nights[editIndex] = nightData;
  } else {
    groupData.nights.push(nightData);
  }
  
  await saveGroupData();
  closeModal('addNightModal');
  showToast('Poker night saved!');
  loadNights();
}
```

### Tab 3: Players

**Search & Sort Controls:**
```html
<input id="playersSearch" placeholder="🔍 Search players..." oninput="loadPlayers()">
<select id="playersSort" onchange="loadPlayers()">
  <option value="winnings">Total Winnings (High-Low)</option>
  <option value="a-z">Name (A-Z)</option>
  <option value="z-a">Name (Z-A)</option>
  <option value="games">Games Played (High-Low)</option>
  <option value="wins">Wins (High-Low)</option>
  <option value="winrate">Win Rate (High-Low)</option>
</select>
```

**Player Card Display:**
```html
<div class="player-card">
  <div class="player-info">
    <div class="player-name">Alice</div>
    <div class="player-stats">10 games • 6 wins • 60% win rate</div>
    <div class="player-stats" style="font-size:11px; opacity:0.7;">
      Joined: Feb 2024
    </div>
  </div>
  <div class="player-winnings positive">+$250.00</div>
  <div style="display:flex; gap:8px;">
    <button class="btn btn-secondary btn-small" onclick="editPlayer(0)">✏️</button>
    <button class="btn btn-danger btn-small" onclick="deletePlayer(0)">🗑️</button>
  </div>
</div>
```

**Add/Edit Player:**
```javascript
async function savePlayer() {
  const name = document.getElementById('playerName').value.trim();
  const editIndex = modal.dataset.editIndex;
  
  if (!groupData.playerInfo) groupData.playerInfo = {};
  
  if (editIndex !== '') {
    // Edit: Update name everywhere
    const oldName = groupData.players[editIndex];
    groupData.players[editIndex] = name;
    
    // Preserve dateAdded
    if (groupData.playerInfo[oldName]) {
      groupData.playerInfo[name] = groupData.playerInfo[oldName];
      delete groupData.playerInfo[oldName];
    }
    
    // Update in all nights
    groupData.nights.forEach(night => {
      night.results.forEach(result => {
        if (result.player === oldName) result.player = name;
      });
    });
  } else {
    // Add new
    groupData.players.push(name);
    groupData.playerInfo[name] = {
      dateAdded: new Date().toISOString()
    };
  }
  
  await saveGroupData();
}
```

### Tab 4: Leaderboard

**Year Filter:**
```html
<select id="leaderboardYearSelect" onchange="loadLeaderboard()">
  <option value="ytd">Year to Date</option>
  <option value="lifetime">Lifetime</option>
  <!-- Dynamically add: 2026, 2025, 2024... -->
</select>
```

**Chart.js Bar Chart:**
```javascript
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: top10Players.map(p => p.name),
    datasets: [{
      data: top10Players.map(p => p.totalWinnings),
      backgroundColor: top10Players.map(p => 
        p.totalWinnings >= 0 ? 'rgba(16,185,129,0.5)' : 'rgba(239,68,68,0.5)'
      ),
      borderColor: top10Players.map(p => 
        p.totalWinnings >= 0 ? 'rgba(16,185,129,1)' : 'rgba(239,68,68,1)'
      ),
      borderWidth: 2
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.1)' } },
      x: { grid: { display: false } }
    }
  }
});
```

**Rankings List:**
- Medals for top 3 (🥇🥈🥉)
- Position numbers for 4+
- Shows: Games, Wins, Win rate, Total winnings
- Color-coded winnings

**Player Stats Calculation:**
```javascript
function calculatePlayerStats(yearFilter = 'ytd') {
  const currentYear = new Date().getFullYear();
  const stats = {};
  
  groupData.players.forEach(p => {
    stats[p] = { totalWinnings: 0, gamesPlayed: 0, wins: 0 };
  });
  
  const filteredNights = groupData.nights.filter(n => {
    const [year] = n.date.split('-');
    const nightYear = parseInt(year);
    
    if (yearFilter === 'ytd') return nightYear === currentYear;
    if (yearFilter === 'lifetime') return true;
    return nightYear === parseInt(yearFilter);
  });
  
  filteredNights.forEach(night => {
    night.results.forEach(r => {
      if (!stats[r.player]) stats[r.player] = { totalWinnings: 0, gamesPlayed: 0, wins: 0 };
      stats[r.player].totalWinnings += r.winnings;
      stats[r.player].gamesPlayed++;
      if (r.winnings > 0) stats[r.player].wins++;
    });
  });
  
  return Object.keys(stats).map(name => ({
    name,
    ...stats[name],
    winRate: stats[name].gamesPlayed > 0 ? 
      Math.round((stats[name].wins / stats[name].gamesPlayed) * 100) : 0
  })).sort((a, b) => b.totalWinnings - a.totalWinnings);
}
```

### Tab 5: Achievements

**Behavior:**
```javascript
// Tab click redirects to external page
<div class="tab" onclick="window.location.href='achievements-enhanced.html?source=admin&group=' + groupId">
  🎖️ Achievements
</div>
```

### Tab 6: Stats

**Lifetime Statistics:**
- Total Games, Total Players
- Total Money (sum of buy-ins)
- Avg/Game
- Biggest Win (player + amount)
- Biggest Loss (player + amount)

### Tab 7: Settlement

**Period Selector:**
```html
<select id="settlementPeriodSelect" onchange="loadSettlement()">
  <option value="ytd">Year to Date</option>
  <option value="unsettled">Unsettled Only</option>
  <option value="lifetime">Lifetime</option>
</select>
<button onclick="markAllSettled()">✓ Mark All Settled</button>
```

**Calculate Settlement (INCLUDING EXPENSES):**
```javascript
function loadSettlement() {
  const nights = filterNightsByPeriod();
  const balances = {};
  
  nights.forEach(night => {
    // Add poker winnings
    night.results.forEach(r => {
      balances[r.player] = (balances[r.player] || 0) + r.winnings;
    });
    
    // Add expense adjustments
    if (night.expenses && night.expenses.length > 0) {
      const totalExpenses = night.expenses.reduce((sum, e) => sum + e.amount, 0);
      const perPerson = totalExpenses / night.results.length;
      
      // Reimbursement
      night.expenses.forEach(e => {
        balances[e.paidBy] = (balances[e.paidBy] || 0) + e.amount;
      });
      
      // Everyone pays share
      night.results.forEach(r => {
        balances[r.player] = (balances[r.player] || 0) - perPerson;
      });
    }
  });
  
  // Generate transactions
  let transactions = calculateTransactions(balances);
  
  // Optimize
  transactions = optimizeSettlement(transactions);
  
  // Filter out settled
  const unsettled = transactions.filter(t => {
    return !groupData.settledTransactions.some(st =>
      st.from === t.from && st.to === t.to && Math.abs(st.amount - t.amount) < 0.01
    );
  });
  
  displaySettlement(unsettled, groupData.settledTransactions);
}
```

**Display:**
- **Unpaid (Red):** Red border, red amount, "● Unpaid", "✓ Paid" button
- **Paid (Green):** Green border, green amount, "✓ Paid on [date]", faded, no button

**Mark as Paid:**
```javascript
async function markTransactionSettled(from, to, amount) {
  if (!groupData.settledTransactions) groupData.settledTransactions = [];
  
  groupData.settledTransactions.push({
    from, to, amount,
    settledDate: new Date().toISOString()
  });
  
  await saveGroupData();
  showToast('Payment marked as settled! 🎉');
  loadSettlement();
}
```

### Tab 8: Wrapped

**Behavior:**
```javascript
// Tab click redirects to external page
<div class="tab" onclick="window.location.href='wrapped.html?source=admin&group=' + groupId">
  🎁 Wrapped
</div>
```

---

## FILE 3: viewer.html

### Implementation
**Copy admin.html and modify:**

**Remove/Hide:**
1. Replace ⚙️ with 👁️ (viewer badge)
2. Hide all ➕ buttons: `style="display:none;"`
3. Hide all ✏️ buttons: `style="display:none;"`
4. Hide all 🗑️ buttons: `style="display:none;"`
5. Hide "✓ Paid" buttons: `style="display:none;"`
6. Hide "Mark All Settled" button: `style="display:none;"`
7. Remove clickability from dashboard cards

**Keep:**
- All tabs viewable
- All search/sort/filter features
- All stats and charts
- Real-time updates
- Links to wrapped & achievements

**Critical:**
- All functions can remain (just hide UI elements)
- Don't remove functions (prevents errors)
- Change links to include `?source=viewer`

---

## FILE 4: wrapped.html

### Structure
- Header with back button
- Period selector (YTD/Lifetime)
- Player selector (All/Individual)
- Player wrapped cards (orange→red gradient)

### Player Wrapped Card

**Components:**
1. **Header:** "🎁 [Name] Poker Wrapped" + period
2. **Stats Grid (2x2):**
   - Games Played (4em font)
   - Total Winnings (4em font)
   - Win Rate % (4em font)
   - Ranking # (4em font)
   - Dark overlay cards

3. **Highlights Section:**
   ```
   ✨ Highlights
   - 🎯 Biggest Win: $XXX
   - 📉 Biggest Loss: $XXX
   - 🔥 Best Streak: +X wins
   - 🎮 Favorite Opponent: Name
   - 📅 Best Month: Month Year ($XXX)
   - 💰 Average per Game: $XXX
   ```

4. **Achievements:** White pill badges

5. **Fortune Cookie:**
   ```html
   <!-- Initial -->
   <div class="fortune-cookie-container" onclick="openFortuneCookie('player-id')">
     <div class="fortune-cookie-icon" style="font-size:5em;">🥠</div>
     <div class="fortune-cookie-text">Click to open your fortune</div>
   </div>
   
   <!-- After animation -->
   <div class="fortune-revealed">
     <div style="font-size:32px;">✨</div>
     <div class="fortune-text">[Random fortune from 100 sayings]</div>
     <div class="fortune-author">— Ancient Poker Wisdom</div>
     <div class="fortune-suits">♠ ♥ ♦ ♣</div>
   </div>
   ```

**Fortune Cookie Animation:**
```javascript
function openFortuneCookie(playerId) {
  const container = document.getElementById('fortune-' + playerId);
  const icon = container.querySelector('.fortune-cookie-icon');
  
  // Shake 0.5s
  icon.classList.add('shake');
  
  setTimeout(() => {
    icon.classList.remove('shake');
    icon.classList.add('break');  // Break 0.5s
    
    setTimeout(() => {
      const fortune = FORTUNES[Math.floor(Math.random() * FORTUNES.length)];
      container.innerHTML = `<div>✨</div><div>${fortune}</div>...`;
      container.className = 'fortune-revealed';  // Reveal 0.8s
      container.onclick = null;
    }, 500);
  }, 500);
}

// CSS animations
@keyframes shake {
  0%, 100% { transform: rotate(0deg); }
  25% { transform: rotate(-10deg); }
  75% { transform: rotate(10deg); }
}

@keyframes break {
  0% { transform: scale(1) rotate(0deg); opacity: 1; }
  100% { transform: scale(1.5) rotate(20deg); opacity: 0; }
}

@keyframes fortuneReveal {
  0% { opacity: 0; transform: translateY(30px) scale(0.5); }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
```

**100 Fortune Sayings:**
```javascript
const FORTUNES = [
  "A bold bluff in your future will change the game. 🔮",
  "The cards you fold today will lead to riches tomorrow. 🎴",
  "Your next big win comes when you least expect it. ✨",
  "Patience at the table brings fortune to the wise. 🧘",
  "The river card holds secrets; trust your instincts. 🌊",
  // ... 95 more (see appendix)
];
```

**Back Button:**
```javascript
function goBack() {
  const urlParams = new URLSearchParams(window.location.search);
  const source = urlParams.get('source') || 'admin';
  window.location.href = `${source}.html?group=${groupId}`;
}
```

---

## FILE 5: achievements-enhanced.html

### Structure
- Header with back button
- 3 filter dropdowns (Year, Player, Badge)
- Achievement stats (3 cards)
- Achievement list

### Filters

**Year Filter:**
```html
<select id="yearSelect" onchange="loadAchievements()">
  <option value="ytd">Year to Date</option>
  <option value="lifetime">Lifetime</option>
  <!-- Dynamically add: 2026, 2025, 2024... -->
</select>
```

**Player Filter:**
```html
<select id="playerFilter" onchange="loadAchievements()">
  <option value="all">All Players</option>
  <!-- Dynamically add all players -->
</select>
```

**Badge Filter:**
```html
<select id="badgeFilter" onchange="loadAchievements()">
  <option value="all">All Badges</option>
  <option value="🎯 Welcome to Club">🎯 Welcome to Club</option>
  <option value="🎲 Veteran Player">🎲 Veteran Player</option>
  <option value="⭐ Dedication">⭐ Dedication</option>
  <option value="🏆 High Roller">🏆 High Roller</option>
  <option value="🔥 Hot Streak">🔥 Hot Streak</option>
  <option value="💰 Big Winner">💰 Big Winner</option>
  <option value="💎 Profit Master">💎 Profit Master</option>
  <option value="💀 Grim Reaper">💀 Grim Reaper</option>
  <option value="🔒 Fortress">🔒 Fortress</option>
  <option value="🏦 Bankroll Builder">🏦 Bankroll Builder</option>
  <option value="🎂 Anniversary">🎂 Anniversary (Any Year)</option>
</select>
```

**Filter Application:**
```javascript
function loadAchievements() {
  let achievements = calculateAllAchievements(nights);
  
  // Filter by player
  if (selectedPlayer !== 'all') {
    achievements = achievements.filter(a => a.player === selectedPlayer);
  }
  
  // Filter by badge (strip emoji from dropdown value)
  if (selectedBadge !== 'all') {
    if (selectedBadge === '🎂 Anniversary') {
      achievements = achievements.filter(a => a.isAnniversary);
    } else {
      const badgeName = selectedBadge.replace(/^[\u{1F000}-\u{1F9FF}]\s+/u, '');
      achievements = achievements.filter(a => a.name === badgeName);
    }
  }
  
  displayAchievements(achievements);
}
```

### 20+ Achievement Types

**Milestone:**
- 🎯 **Welcome to Club:** 1st game played

**Experience:**
- 🎲 **Veteran Player:** 10+ games
- ⭐ **Dedication:** 50+ games

**Skill:**
- 🏆 **High Roller:** 60%+ win rate (min 5 games)

**Streak:**
- 🔥 **Hot Streak:** 3+ consecutive wins

**Money:**
- 💰 **Big Winner:** Single win $100+
- 💎 **Profit Master:** $500+ total

**Dominance:**
- 💀 **Grim Reaper:** Eliminate 3+ players in one night

**Consistency:**
- 🔒 **Fortress:** 5+ consecutive games without going bust (winnings ≥ 0)
- 🏦 **Bankroll Builder:** 3+ consecutive months with positive winnings

**Anniversary:**
- 🎂 **1-10 Year Anniversaries:** Years since player added

**Achievement Calculation Example:**
```javascript
// Fortress (no-bust streak)
let consecutiveNoBust = 0;
let maxConsecutiveNoBust = 0;

sortedNights.forEach(night => {
  night.results.forEach(r => {
    if (r.player === playerName) {
      if (r.winnings >= 0) {
        consecutiveNoBust++;
        if (consecutiveNoBust > maxConsecutiveNoBust) {
          maxConsecutiveNoBust = consecutiveNoBust;
        }
      } else {
        consecutiveNoBust = 0;
      }
    }
  });
});

if (maxConsecutiveNoBust >= 5) {
  achievements.push({
    icon: '🔒',
    name: 'Fortress',
    player: playerName,
    description: `${maxConsecutiveNoBust} games without going bust`,
    date: 'Season',
    category: 'consistency'
  });
}
```

**Anniversary Calculation:**
```javascript
if (playerInfo[playerName]?.dateAdded) {
  const dateAdded = new Date(playerInfo[playerName].dateAdded);
  const yearsSince = Math.floor(
    (currentDate - dateAdded) / (365.25 * 24 * 60 * 60 * 1000)
  );
  
  if (yearsSince >= 1 && yearsSince <= 10) {
    achievements.push({
      icon: '🎂',
      name: `${yearsSince} Year Anniversary`,
      player: playerName,
      description: `Member since ${dateAdded.toLocaleDateString()}`,
      date: playerInfo[playerName].dateAdded.split('T')[0],
      category: 'anniversary',
      isAnniversary: true
    });
  }
}
```

---

## SETTLEMENT ALGORITHM (CRITICAL)

### Basic Transactions
```javascript
function calculateTransactions(balances) {
  const owes = [];  // Negative balances
  const owed = [];  // Positive balances
  
  Object.keys(balances).forEach(player => {
    const balance = Math.round(balances[player] * 100) / 100;
    if (balance < -0.01) {
      owes.push({ name: player, totalWinnings: balance });
    } else if (balance > 0.01) {
      owed.push({ name: player, totalWinnings: balance });
    }
  });
  
  const transactions = [];
  let owesClone = owes.map(p => ({...p}));
  let owedClone = owed.map(p => ({...p}));
  
  for (let debtor of owesClone) {
    let debt = Math.abs(debtor.totalWinnings);
    
    for (let creditor of owedClone) {
      if (debt <= 0) break;
      if (creditor.totalWinnings <= 0) continue;
      
      const amount = Math.min(debt, creditor.totalWinnings);
      transactions.push({ from: debtor.name, to: creditor.name, amount });
      
      debt -= amount;
      creditor.totalWinnings -= amount;
    }
  }
  
  return transactions;
}
```

### Optimization Algorithm (5 Steps)

**Input:** Array of `{from, to, amount}` transactions  
**Output:** Minimized array of transactions

```javascript
function optimizeSettlement(transactions) {
  // STEP 1: Net out opposite directions
  const debts = {};
  
  transactions.forEach(t => {
    const key = t.from + '||' + t.to;
    const reverseKey = t.to + '||' + t.from;
    
    if (debts[reverseKey]) {
      const existing = debts[reverseKey];
      if (existing > t.amount) {
        debts[reverseKey] = existing - t.amount;
      } else if (existing < t.amount) {
        delete debts[reverseKey];
        debts[key] = t.amount - existing;
      } else {
        delete debts[reverseKey];
      }
    } else {
      debts[key] = (debts[key] || 0) + t.amount;
    }
  });
  
  // STEP 2: Calculate net balances
  const netBalance = {};
  Object.keys(debts).forEach(key => {
    const [from, to] = key.split('||');
    const amount = debts[key];
    netBalance[from] = (netBalance[from] || 0) - amount;
    netBalance[to] = (netBalance[to] || 0) + amount;
  });
  
  // STEP 3: Separate debtors and creditors
  const debtors = [];
  const creditors = [];
  Object.keys(netBalance).forEach(person => {
    const balance = Math.round(netBalance[person] * 100) / 100;
    if (balance < -0.01) {
      debtors.push({ person, amount: -balance });
    } else if (balance > 0.01) {
      creditors.push({ person, amount: balance });
    }
  });
  
  // STEP 4: Sort (largest first)
  debtors.sort((a, b) => b.amount - a.amount);
  creditors.sort((a, b) => b.amount - a.amount);
  
  // STEP 5: Greedy algorithm
  const optimized = [];
  let i = 0, j = 0;
  const debtorsCopy = debtors.map(d => ({...d}));
  const creditorsCopy = creditors.map(c => ({...c}));
  
  while (i < debtorsCopy.length && j < creditorsCopy.length) {
    const debtor = debtorsCopy[i];
    const creditor = creditorsCopy[j];
    const amount = Math.min(debtor.amount, creditor.amount);
    
    if (amount > 0.01) {
      optimized.push({
        from: debtor.person,
        to: creditor.person,
        amount: Math.round(amount * 100) / 100
      });
    }
    
    debtor.amount -= amount;
    creditor.amount -= amount;
    
    if (debtor.amount < 0.01) i++;
    if (creditor.amount < 0.01) j++;
  }
  
  return optimized;
}
```

**Example:**
- Input: [A→B $20, B→C $20, A→B $10, C→A $15]
- After Step 1: [A→B $30, B→C $20, C→A $15]
- After Steps 2-5: [A→C $5, C→B $10]
- Reduced from 4 to 2 transactions!

### Per-Night Settlement (3 Columns)

**Poker Column (Orange #f39c12):**
```javascript
const pokerBalances = {};
playerResults.forEach(r => {
  pokerBalances[r.player] = r.winnings;
});
const pokerTransactions = calculateTransactions(pokerBalances);
```

**Expenses Column (Green #2ecc71):**
```javascript
const expenseBalances = {};
const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
const perPerson = totalExpenses / playerResults.length;

playerResults.forEach(r => {
  expenseBalances[r.player] = 0;
});

expenses.forEach(e => {
  expenseBalances[e.paidBy] += e.amount;
});

playerResults.forEach(r => {
  expenseBalances[r.player] -= perPerson;
});

const expenseTransactions = calculateTransactions(expenseBalances);
```

**Optimized Column (Purple #9b59b6):**
```javascript
const combinedBalances = {};
playerResults.forEach(r => {
  combinedBalances[r.player] = r.winnings;
});

if (expenses.length > 0) {
  expenses.forEach(e => {
    combinedBalances[e.paidBy] += e.amount;
  });
  playerResults.forEach(r => {
    combinedBalances[r.player] -= perPerson;
  });
}

const allTransactions = [
  ...pokerTransactions.map(t => ({...t})),
  ...expenseTransactions.map(t => ({...t}))
];

const optimized = optimizeSettlement(allTransactions);
```

**Display:**
```html
<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:15px;">
  <!-- Poker Column -->
  <div>
    <div style="text-align:center; color:#f39c12; border-bottom:2px solid #f39c12;">
      🃏 Poker
    </div>
    <!-- Transactions -->
  </div>
  
  <!-- Expenses Column -->
  <div>
    <div style="text-align:center; color:#2ecc71; border-bottom:2px solid #2ecc71;">
      💰 Expenses
    </div>
    <div>Total: $XXX</div>
    <!-- Transactions -->
  </div>
  
  <!-- Optimized Column (HIGHLIGHTED) -->
  <div style="border:2px solid #9b59b6; border-radius:12px; padding:15px;">
    <div style="text-align:center; color:#9b59b6;">
      📊 Optimized
    </div>
    <div>✨ Reduced to X payments</div>
    <!-- Transactions -->
    <div style="text-align:center; color:#9b59b6; font-size:12px;">
      ✨ Use these simplified payments
    </div>
  </div>
</div>
```

---

## REAL-TIME SYNC PATTERN

**Setup (Every Page):**
```javascript
async function init() {
  // Wait for Firebase
  if (!window.firebaseReady || !window.db) {
    setTimeout(init, 100);
    return;
  }
  
  // Get group ID from URL
  const urlParams = new URLSearchParams(window.location.search);
  groupId = urlParams.get('group');
  
  if (!groupId) {
    window.location.href = 'index.html';
    return;
  }
  
  // Load initial data
  await loadGroupData();
  
  // Real-time listener
  const groupRef = window.firestore.doc(window.db, 'groups', groupId);
  window.firestore.onSnapshot(groupRef, (doc) => {
    if (doc.exists()) {
      groupData = doc.data();
      updateUI();  // Refresh current view
    }
  });
}

async function loadGroupData() {
  const groupRef = window.firestore.doc(window.db, 'groups', groupId);
  const groupSnap = await window.firestore.getDoc(groupRef);
  
  if (!groupSnap.exists()) {
    alert('Group not found');
    window.location.href = 'index.html';
    return;
  }
  
  groupData = groupSnap.data();
  
  // Initialize missing fields
  if (!groupData.players) groupData.players = [];
  if (!groupData.nights) groupData.nights = [];
  if (!groupData.playerInfo) groupData.playerInfo = {};
  if (!groupData.settledTransactions) groupData.settledTransactions = [];
  if (!groupData.settings) groupData.settings = { currency: '$', defaultBuyIn: 20 };
  
  // Load initial view
  updateDashboard();
}

async function saveGroupData() {
  const groupRef = window.firestore.doc(window.db, 'groups', groupId);
  await window.firestore.updateDoc(groupRef, groupData);
}
```

---

## CRITICAL IMPLEMENTATION DETAILS

### Date Handling (Timezone-Safe)
```javascript
// WRONG (timezone issues)
new Date("2024-02-05")  // Treats as UTC, converts to local

// CORRECT
function formatDate(dateStr) {
  const [year, month, day] = dateStr.split('-');
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('en-US', { 
    month: 'short', day: 'numeric', year: 'numeric' 
  });
}
```

### Currency Formatting
```javascript
function formatCurrency(amount) {
  const currency = groupData.settings?.currency || '$';
  return currency + Math.abs(amount).toFixed(2);
}

// Display: $25.00 (always 2 decimals)
```

### Duplicate Prevention
```javascript
// When populating dropdowns with real-time updates
function populatePlayerDropdown() {
  const select = document.getElementById('playerFilter');
  
  // Clear existing (except first option)
  while (select.options.length > 1) {
    select.remove(1);
  }
  
  // Re-add all players
  groupData.players.forEach(player => {
    const option = document.createElement('option');
    option.value = player;
    option.textContent = player;
    select.appendChild(option);
  });
}

// Call ONLY on initial load and when players array changes
// NOT on every loadAchievements() call
```

### Year Dropdown Population
```javascript
function populateYearDropdown() {
  const yearSelect = document.getElementById('leaderboardYearSelect');
  
  // Get unique years from nights
  const years = [...new Set(groupData.nights.map(n => {
    const [year] = n.date.split('-');
    return parseInt(year);
  }))].sort((a, b) => b - a);
  
  // Clear existing (except YTD and Lifetime)
  while (yearSelect.options.length > 2) {
    yearSelect.remove(2);
  }
  
  // Add years
  years.forEach(year => {
    const option = document.createElement('option');
    option.value = year;
    option.textContent = year;
    yearSelect.appendChild(option);
  });
}
```

---

## SEARCH & SORT IMPLEMENTATION

### Pattern for All Search Boxes
```javascript
function loadData() {
  let data = [...originalData];
  
  // Search
  const searchTerm = document.getElementById('searchBox')?.value.toLowerCase() || '';
  if (searchTerm) {
    data = data.filter(item => {
      // Match against relevant fields
      return item.field1.toLowerCase().includes(searchTerm) ||
             item.field2.toLowerCase().includes(searchTerm);
    });
  }
  
  // Sort
  const sortBy = document.getElementById('sortSelect')?.value || 'default';
  if (sortBy === 'option1') {
    data.sort((a, b) => /* comparison */);
  }
  
  // Display
  displayData(data);
}
```

### Nights Sort Options
```javascript
if (sortBy === 'newest') {
  nights.sort((a, b) => b.date.localeCompare(a.date));
} else if (sortBy === 'oldest') {
  nights.sort((a, b) => a.date.localeCompare(b.date));
} else if (sortBy === 'pot-high') {
  nights.sort((a, b) => {
    const potA = a.results.reduce((sum, r) => sum + (r.totalBuyIn || a.buyIn), 0);
    const potB = b.results.reduce((sum, r) => sum + (r.totalBuyIn || b.buyIn), 0);
    return potB - potA;
  });
} else if (sortBy === 'location') {
  nights.sort((a, b) => (a.location || 'zzz').localeCompare(b.location || 'zzz'));
} else if (sortBy === 'winner') {
  nights.sort((a, b) => {
    const winnerA = a.results.length > 0 ? 
      a.results.reduce((max, r) => r.winnings > max.winnings ? r : max, a.results[0]).player : '';
    const winnerB = b.results.length > 0 ? 
      b.results.reduce((max, r) => r.winnings > max.winnings ? r : max, b.results[0]).player : '';
    return winnerA.localeCompare(winnerB);
  });
}
```

### Players Sort Options
```javascript
if (sortBy === 'winnings') {
  playerStats.sort((a, b) => b.totalWinnings - a.totalWinnings);
} else if (sortBy === 'a-z') {
  playerStats.sort((a, b) => a.name.localeCompare(b.name));
} else if (sortBy === 'z-a') {
  playerStats.sort((a, b) => b.name.localeCompare(a.name));
} else if (sortBy === 'games') {
  playerStats.sort((a, b) => b.gamesPlayed - a.gamesPlayed);
} else if (sortBy === 'wins') {
  playerStats.sort((a, b) => b.wins - a.wins);
} else if (sortBy === 'winrate') {
  playerStats.sort((a, b) => b.winRate - a.winRate);
}
```

---

## MODAL PATTERNS

### Open/Close Pattern
```javascript
function openModal(modalId) {
  document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('active');
  // Reset form if needed
}

// Click outside to close
<div class="modal" onclick="if(event.target === this) closeModal('modalId')">
  <div class="modal-content" onclick="event.stopPropagation()">
    <!-- Content -->
  </div>
</div>
```

### Edit vs Add Detection
```javascript
function openAddNightModal() {
  // Clear form
  document.getElementById('nightDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('addNightModal').dataset.editIndex = '';
  document.querySelector('#addNightModal .modal-title').textContent = 'Add Poker Night';
  openModal('addNightModal');
}

function editNight(index) {
  // Pre-fill form
  const night = groupData.nights[index];
  document.getElementById('nightDate').value = night.date;
  document.getElementById('addNightModal').dataset.editIndex = index;
  document.querySelector('#addNightModal .modal-title').textContent = 'Edit Poker Night';
  // ... populate all fields
  openModal('addNightModal');
}

async function saveNight() {
  const editIndex = document.getElementById('addNightModal').dataset.editIndex;
  
  if (editIndex !== '') {
    // Update existing
    groupData.nights[parseInt(editIndex)] = nightData;
  } else {
    // Add new
    groupData.nights.push(nightData);
  }
  
  await saveGroupData();
}
```

---

## DYNAMIC FORM ELEMENTS

### Adding Player Result Rows
```javascript
function addPlayerResult(playerName = '', totalBuyIn = '', cashOut = '') {
  const container = document.getElementById('nightPlayersContainer');
  const players = groupData.players || [];
  const defaultBuyIn = parseFloat(document.getElementById('nightBuyIn').value) || 20;
  
  const div = document.createElement('div');
  div.className = 'player-result';
  div.innerHTML = `
    <select class="form-select" style="flex:2;" onchange="updateBalanceCheck()">
      <option value="">Select Player</option>
      ${players.map(p => `<option value="${p}" ${p === playerName ? 'selected' : ''}>${p}</option>`).join('')}
    </select>
    <input type="number" class="form-input" placeholder="Buy-in" step="0.01" 
           style="flex:1;" value="${totalBuyIn || defaultBuyIn}" 
           title="Total invested (including rebuys)" 
           oninput="updateBalanceCheck()">
    <input type="number" class="form-input" placeholder="Cash Out" step="0.01" 
           style="flex:1." value="${cashOut}" 
           title="Amount cashed out" 
           oninput="updateBalanceCheck()">
    <button class="remove-player-btn" onclick="this.parentElement.remove(); updateBalanceCheck();">×</button>
  `;
  container.appendChild(div);
  
  setTimeout(updateBalanceCheck, 50);
}
```

**Styling:**
```css
.player-result {
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
  align-items: center;
}

.remove-player-btn {
  background: rgba(239, 68, 68, 0.1);
  border: 1px solid var(--error);
  color: var(--error);
  width: 32px;
  height: 32px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 16px;
}
```

---

## VALIDATION RULES

### Balance Check
```
Sum(totalBuyIn) MUST equal Sum(cashOut) within $0.01

IF balanced:
  Green indicator: ✅ Balanced!
  
IF unbalanced:
  Red indicator: ⚠️ Off by ±$X.XX
  Show breakdown
  
Still allow save (warning only, not blocking)
```

### Player Names
```
- Required
- Unique within group (case-sensitive)
- Free text (unicode supported)
- Recommend max 20 chars
```

### Passwords
```
- Minimum 6 characters
- No maximum (reasonable ~50)
- Hash with SHA-256 before storing
- Never store plain text
```

### Dates
```
- Format: YYYY-MM-DD
- Can be future dates (for planning)
- Display format: "Feb 5, 2024"
```

### Amounts
```
- Must be >= 0
- 2 decimal precision
- Number type (not string)
```

---

## HELPER FUNCTIONS

### Toast Notification
```javascript
function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = 'toast show' + (isError ? ' error' : '');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// HTML
<div class="toast" id="toast"></div>

// CSS
.toast {
  position: fixed;
  bottom: 100px;
  left: 50%;
  transform: translateX(-50%) translateY(100px);
  background: var(--success);
  color: white;
  padding: 15px 25px;
  border-radius: 12px;
  z-index: 2000;
  opacity: 0;
  transition: all 0.3s ease;
}

.toast.show {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}

.toast.error {
  background: var(--error);
}
```

### Format Date
```javascript
function formatDate(dateStr) {
  const [year, month, day] = dateStr.split('-');
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('en-US', { 
    month: 'short', day: 'numeric', year: 'numeric' 
  });
}
```

### Format Currency
```javascript
function formatCurrency(amount) {
  const currency = groupData.settings?.currency || '$';
  return currency + Math.abs(amount).toFixed(2);
}
```

---

## KEY UX PATTERNS

### Clickable Dashboard Cards
```html
<!-- Recent nights -->
<div class="player-card" onclick="editNight(${actualIndex})" style="cursor:pointer;">
  <div>${formatDate(night.date)}</div>
  <div>${night.location}</div>
</div>

<!-- Top players -->
<div class="player-card" onclick="switchTab('leaderboard')" style="cursor:pointer;">
  <div>${player.name}</div>
  <div>${formatCurrency(player.totalWinnings)}</div>
</div>
```

### Confirmation Dialogs
```javascript
async function deleteNight(index) {
  if (!confirm('Delete this poker night? This cannot be undone.')) {
    return;
  }
  
  groupData.nights.splice(index, 1);
  await saveGroupData();
  showToast('Night deleted');
  loadNights();
}
```

### Error Handling
```javascript
try {
  await window.firestore.updateDoc(groupRef, groupData);
  showToast('Saved successfully!');
} catch (error) {
  console.error('Error:', error);
  showToast('Error saving: ' + error.message, true);
}
```

---

## RESPONSIVE DESIGN

### Breakpoints
```css
/* Mobile first (default) */

/* Tablet */
@media (max-width: 768px) {
  .stats-grid { grid-template-columns: repeat(2, 1fr); }
  .tabs { gap: 6px; }
  table { font-size: 13px; }
}

/* Mobile */
@media (max-width: 480px) {
  .container { padding: 15px; }
  .glass-card { padding: 20px; }
}
```

### Touch Targets
```
Minimum 44px × 44px for all clickable elements
```

---

## PERFORMANCE

### Chart Management
```javascript
// Destroy before recreating (memory leak prevention)
if (leaderboardChart) {
  leaderboardChart.destroy();
}
leaderboardChart = new Chart(ctx, config);
```

### Selective Updates
```javascript
// Don't re-render entire page
// Update only active tab when data changes
function updateUI() {
  const activeTab = getActiveTab();
  if (activeTab === 'dashboard') updateDashboard();
  else if (activeTab === 'nights') loadNights();
  // etc.
}
```

---

## APPENDIX: 100 FORTUNE COOKIE SAYINGS

```javascript
const FORTUNES = [
  "A bold bluff in your future will change the game. 🔮",
  "The cards you fold today will lead to riches tomorrow. 🎴",
  "Your next big win comes when you least expect it. ✨",
  "Patience at the table brings fortune to the wise. 🧘",
  "The river card holds secrets; trust your instincts. 🌊",
  "Three of a kind approaches in your near future. 🎰",
  "Your poker face will be tested soon—stay strong. 😎",
  "A straight draw awaits; know when to chase it. 🎯",
  "Fortune favors the aggressive player this month. 💪",
  "Your nemesis will fall before year's end. ⚔️",
  "The full house you seek is closer than you think. 🏠",
  "Beware the trap of pocket aces—humility wins. 🃏",
  "Your lucky seat is on the dealer's left. 🪑",
  "A royal flush dances in your destiny. 👑",
  "The best hand is the one you don't play. 🎭",
  "Your chip stack grows with every folded ego. 📈",
  "Bad beats today become lessons for tomorrow. 📚",
  "The poker gods smile upon the patient. 😇",
  "Your greatest victory comes from a conservative play. 🛡️",
  "Trust the odds, but never ignore the reads. 🎲",
  "The turn card will favor you in three games' time. 🔄",
  "A small pot today prevents a big loss tomorrow. 🎯",
  "Your biggest opponent is your own tilt. 🧠",
  "The chips will flow back to the disciplined. 💎",
  "A flush draw beckons, but kings lie in wait. ⚠️",
  "Your fortune changes with the shuffle of cards. 🔀",
  "The next session brings redemption for past losses. 🌅",
  "Slow play will trap the aggressive this week. 🪤",
  "Your reads sharpen with each hand observed. 👁️",
  "The flop will favor suited connectors soon. 🎪",
  "A cooler approaches—accept it with grace. ❄️",
  "Your stack doubles when you trust your gut. 🎰",
  "The button position is your friend tonight. 🔘",
  "A stone-cold bluff will work in your favor soon. 🗿",
  "Your continuation bet will be called—plan accordingly. 📞",
  "The check-raise is a weapon; wield it wisely. ⚔️",
  "Your range advantage grows with study. 📖",
  "A hero call will define your next session. 🦸",
  "The donkey bet will confuse and conquer. 🫏",
  "Your implied odds are better than you think. 💭",
  "A rainbow flop favors the prepared mind. 🌈",
  "Your position speaks louder than your cards. 📍",
  "The min-raise hides strength in your future. 💪",
  "A limp will cost you dearly this month. 🚶",
  "Your all-in will be met with a fold soon. 🎊",
  "The nuts are not always what they seem. 🥜",
  "Your equity realizes itself through aggression. ⚡",
  "A set will crack your overpair—tread carefully. 💔",
  "Your bankroll management ensures longevity. 💰",
  "The bad run ends with discipline, not desperation. 🎯",
  "Your next session favors early position raises. 🌄",
  "A polarized range will serve you well tonight. ⚖️",
  "Your value bets are too thin—size up! 📏",
  "The semi-bluff is your path to profit. 🌓",
  "Your opponents fear your tight image. 🔒",
  "A loose table calls for patient value. 🎣",
  "Your blockers matter more than you realize. 🚫",
  "The ICM pressure will test your resolve. ⏰",
  "Your fold equity increases with table image. 🖼️",
  "A double barrel will take down the pot. 🎯",
  "Your check-back induces a bluff tomorrow. 🎭",
  "The iso-raise will isolate the fish perfectly. 🐟",
  "Your 3-bet range needs more balance. ⚖️",
  "A delayed c-bet will maximize value soon. ⏳",
  "Your river decision makes or breaks the night. 🌊",
  "The board texture favors your holdings tonight. 🎨",
  "Your pot control will save chips this week. 🛡️",
  "A float play will win you an unexpected pot. 🎈",
  "Your squeeze play is coming—timing is key. 🤏",
  "The overbet will get called; proceed with caution. ⚠️",
  "Your hand reading improves with every showdown. 🔍",
  "A block bet will save you from a tough decision. 🧱",
  "Your probe bet will gather valuable information. 🔬",
  "The donk bet will confuse your next opponent. 🎪",
  "Your bet sizing tells a story—make it compelling. 📖",
  "A merge range will balance your strategy. 🔀",
  "Your c-bet frequency is predictable—mix it up! 🎲",
  "The double-suited hand will hit harder than expected. 💥",
  "Your gap concept needs refinement. 📐",
  "A well-timed check will induce maximum value. ✅",
  "Your aggression factor is your secret weapon. 🗡️",
  "The suited ace will betray you—play cautiously. 🃏",
  "Your continuation range is too wide; tighten up! 🎯",
  "A runner-runner will save you when hope seems lost. 🏃",
  "Your fold to 3-bet is too high—defend more! 🛡️",
  "The pocket pair will set mine successfully tonight. ⛏️",
  "Your steal attempts increase with stack depth. 📊",
  "A polarizing river bet will get paid. 💸",
  "Your opponents can't put you on a hand—good! 🎭",
  "The suited connector will flop a monster soon. 🐉",
  "Your GTO knowledge is a shield, not a sword. 🛡️",
  "A leveling war approaches—stay one step ahead. 🧠",
  "Your table selection matters more than card luck. 🎯",
  "The rake will take its toll—play bigger pots! 💰",
  "Your showdown value is underrated tonight. 💎",
  "A crying call will be correct in your next session. 😢",
  "Your range construction determines long-term success. 🏗️",
  "The variance will even out—trust the process. 📈",
  "Your mental game is your greatest asset. 🧘‍♂️",
  "A cooler is coming; don't let it tilt you. 🧊",
  "Your note-taking will pay dividends soon. 📝",
  "The Friday night game will test your skills. 🌙",
  "Your bankroll grows through smart game selection. 🎮"
];
```

---

## TESTING CHECKLIST

### Critical Paths to Test

**1. Create Group Flow:**
- [ ] Auto-generate code works (format: XXXX-XXXX)
- [ ] Custom code works
- [ ] Password hashing works
- [ ] Saves to Firebase
- [ ] Saves to localStorage
- [ ] Success screen shows
- [ ] Enter Group redirects correctly

**2. Add Night with Rebuys:**
- [ ] Player results auto-populate
- [ ] Buy-in field accepts rebuys
- [ ] Balance check updates live
- [ ] Green when balanced
- [ ] Red when unbalanced
- [ ] Can add expenses
- [ ] Calculate Settlement shows 3 columns
- [ ] Optimized column reduces transactions
- [ ] Save works

**3. Global Settlement:**
- [ ] Includes poker winnings
- [ ] Includes expenses (split evenly)
- [ ] Optimization algorithm runs
- [ ] Shows unpaid in red
- [ ] Shows paid in green
- [ ] Mark as Paid works
- [ ] Updates real-time

**4. Search & Sort:**
- [ ] Nights search by date/location
- [ ] Nights sort by all 6 options
- [ ] Players search by name
- [ ] Players sort by all 6 options
- [ ] Real-time filtering (no search button)

**5. Real-Time Sync:**
- [ ] Open 2 browsers, same group
- [ ] Edit in Browser A
- [ ] Browser B updates automatically
- [ ] No page refresh needed

**6. Viewer Mode:**
- [ ] Login with viewer password
- [ ] No edit buttons visible
- [ ] Can view all data
- [ ] Search/sort works
- [ ] Cannot save changes
- [ ] Wrapped/Achievements back to viewer.html

**7. Achievements:**
- [ ] All 20 types calculate correctly
- [ ] Year filter works
- [ ] Player filter works
- [ ] Badge filter works (strips emoji)
- [ ] Anniversary badges show for 1-10 years
- [ ] Golden styling for anniversaries

**8. Wrapped:**
- [ ] Period selector works
- [ ] Player selector works
- [ ] Stats calculate correctly
- [ ] Fortune cookie animates
- [ ] Shake → Break → Reveal sequence
- [ ] Random fortune displays
- [ ] Not clickable after opening

---

## EDGE CASES TO HANDLE

### Data
- [ ] Empty group (no players, no nights)
- [ ] Player with no games
- [ ] Night with no results
- [ ] Night with only 1 player
- [ ] Unbalanced buy-in/cash-out (allow with warning)
- [ ] Negative cash out (unusual but allow)
- [ ] Future dates (allow)
- [ ] Missing playerInfo.dateAdded (show "Unknown")
- [ ] Old data without totalBuyIn (fallback to night.buyIn)

### UI
- [ ] Empty search results
- [ ] Very long player names (truncate or wrap)
- [ ] Very long location names
- [ ] 100+ nights (performance ok?)
- [ ] No internet connection (show error)
- [ ] Firebase quota exceeded (show error)

### Browser
- [ ] localStorage cleared (group list empty, allow rejoin)
- [ ] Duplicate tabs same group (both work with sync)
- [ ] Old browser (graceful degradation)

---

## DEPLOYMENT

### Firebase Setup
1. Create project at console.firebase.google.com
2. Enable Firestore Database
3. Paste security rules
4. Get config object (API key, etc.)
5. Update firebaseConfig in all HTML files

### File Upload
Upload 5 HTML files to web host:
- index.html
- admin.html
- viewer.html
- wrapped.html
- achievements-enhanced.html

### Hosting Options
- GitHub Pages (free)
- Netlify (easiest, drag & drop)
- Vercel (free)
- Firebase Hosting (integrated)

### Test
1. Open index.html
2. Create group
3. Add players (check dateAdded tracked)
4. Add poker night with rebuys
5. Check balance indicator
6. Add expenses
7. Calculate settlement
8. Mark as paid
9. Test all tabs
10. Test search/sort
11. Open wrapped
12. Open achievements
13. Test in incognito as viewer

---

## BUILD INSTRUCTIONS FOR AI

**When building this app:**

1. **Start with index.html:**
   - Create landing page first
   - Get Firebase working
   - Test group creation

2. **Build admin.html incrementally:**
   - Header → Dashboard → Nights tab → Players tab → etc.
   - Test each tab before moving to next
   - Add modals as needed

3. **Copy admin.html to create viewer.html:**
   - Remove edit capabilities
   - Keep all data display

4. **Create wrapped.html:**
   - Separate file
   - Focus on stats calculations
   - Fortune cookie feature

5. **Create achievements-enhanced.html:**
   - Separate file
   - All 20 achievement types
   - Filter logic

6. **Test thoroughly:**
   - All user flows
   - Edge cases
   - Multi-user sync
   - Mobile responsiveness

---

## COMMON PITFALLS TO AVOID

❌ **Don't:** Use `new Date(dateString)` directly → Timezone issues  
✅ **Do:** Parse components: `new Date(year, month-1, day)`

❌ **Don't:** Populate dropdowns on every render → Duplicates  
✅ **Do:** Populate once, clear and re-add on data change

❌ **Don't:** Forget to destroy charts → Memory leaks  
✅ **Do:** `if (chart) chart.destroy()` before new Chart()

❌ **Don't:** Calculate total pot from money changed hands  
✅ **Do:** Sum all totalBuyIn values (actual chips on table)

❌ **Don't:** Forget expenses in global settlement  
✅ **Do:** Include expense adjustments in balance calculation

❌ **Don't:** Compare badge filter with emoji included  
✅ **Do:** Strip emoji before comparison

❌ **Don't:** Hardcode 'admin.html' in back buttons  
✅ **Do:** Use source parameter to detect origin

❌ **Don't:** Block save if unbalanced  
✅ **Do:** Warn with red indicator but allow save

---

## OUTPUT DELIVERABLES

Generate these 6 files:

1. **index.html** (~27KB)
2. **admin.html** (~100KB)
3. **viewer.html** (~90KB)
4. **wrapped.html** (~30KB)
5. **achievements-enhanced.html** (~25KB)
6. **firestore.rules** (<1KB)

All files should:
- Use exact color scheme above
- Include all animations
- Be mobile-responsive
- Have glassmorphism styling
- Work together seamlessly
- Include real-time Firebase sync

---

**END OF AI CODING PROMPT**

This document contains everything needed to rebuild Poker Night Manager V3 from scratch.
