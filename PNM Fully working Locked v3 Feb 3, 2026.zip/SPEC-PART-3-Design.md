# Poker Night Manager - Technical Specification
## Part 3: UI/UX Design System & Components

---

## 1. Design Philosophy

### 1.1 Core Aesthetic
**"Modern Glassmorphism with Poker Heritage"**

**Visual Principles:**
- Frosted glass layers (backdrop-filter: blur)
- Deep space backgrounds (dark navy gradients)
- Vibrant accent colors (purple, cyan)
- Smooth animations (0.3s transitions)
- Premium feel (shadows, glows, depth)

**Poker Theme Integration:**
- Card suit decorations (♠ ♥ ♦ ♣)
- Floating poker chip animations
- Casino-inspired colors (orange for Big Winner, green for money)
- Gradient cards for Wrapped (orange → red)
- Monospace fonts for codes/numbers (retro casino feel)

---

## 2. Color System

### 2.1 CSS Custom Properties

```css
:root {
  /* Primary Colors */
  --primary-dark: #0a0e27;      /* Deep navy, main background */
  --primary-blue: #1a1f4d;      /* Dark blue, gradient end, cards */
  
  /* Accent Colors */
  --accent-purple: #6366f1;     /* Primary accent, buttons, highlights */
  --accent-cyan: #06b6d4;       /* Secondary accent, gradients, links */
  
  /* Glassmorphism */
  --glass-bg: rgba(255, 255, 255, 0.05);    /* 5% white */
  --glass-border: rgba(255, 255, 255, 0.1); /* 10% white */
  
  /* Text Colors */
  --text-primary: #f8fafc;      /* Near white, main text */
  --text-secondary: #cbd5e1;    /* Light gray, labels, secondary */
  
  /* Semantic Colors */
  --success: #10b981;           /* Green, positive, wins */
  --error: #ef4444;             /* Red, negative, losses, errors */
  --warning: #f59e0b;           /* Orange, warnings */
}
```

### 2.2 Color Usage Guidelines

**Backgrounds:**
```css
/* Page background */
background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-blue) 100%);

/* Glass cards */
background: var(--glass-bg);
border: 1px solid var(--glass-border);
backdrop-filter: blur(10px);

/* Modals */
background: var(--primary-blue);  /* Solid color for modal content */
backdrop: rgba(10, 14, 39, 0.95);  /* Dark semi-transparent overlay */
```

**Buttons:**
```css
/* Primary button */
background: linear-gradient(135deg, var(--accent-purple), var(--accent-cyan));
/* Purple to cyan gradient */

/* Secondary button */
background: var(--glass-bg);
border: 2px solid var(--glass-border);

/* Danger button */
background: rgba(239, 68, 68, 0.1);
border: 1px solid var(--error);
color: var(--error);
```

**Status Indicators:**
```css
/* Positive (wins, balanced) */
color: var(--success);  /* #10b981 green */

/* Negative (losses, unbalanced) */
color: var(--error);    /* #ef4444 red */

/* Neutral (info) */
color: var(--text-secondary);  /* #cbd5e1 gray */
```

**Settlement Colors (Specific):**
```css
/* Poker column */
border-color: #f39c12;  /* Orange */

/* Expenses column */
border-color: #2ecc71;  /* Green */

/* Optimized column */
border-color: #9b59b6;  /* Purple */
border-width: 2px;      /* Thicker to emphasize */
```

---

## 3. Typography

### 3.1 Font Families

**Primary Font: Outfit**
```css
font-family: 'Outfit', sans-serif;
```

**Usage:**
- All body text
- Headings
- Buttons
- Form inputs
- UI labels

**Weights Available:**
- 400 (Regular) - Body text
- 500 (Medium) - Emphasized text
- 600 (Semibold) - Subheadings, labels
- 700 (Bold) - Headings, important numbers
- 800 (Extrabold) - Large headings, hero text

**Monospace Font: Space Mono**
```css
font-family: 'Space Mono', monospace;
```

**Usage:**
- Group codes (POKER-X7Y2)
- Timestamps
- Achievement dates
- Dollar amounts (in some contexts)
- Logo icon (♠♥)

**Weights Available:**
- 400 (Regular)
- 700 (Bold)

---

### 3.2 Type Scale

```css
/* Display */
.logo-text {
  font-size: 32px;
  font-weight: 800;
  line-height: 1.2;
}

/* H1 - Page titles */
.card-title {
  font-size: 24px;
  font-weight: 700;
  line-height: 1.3;
}

/* H2 - Section titles */
.modal-title {
  font-size: 22px;
  font-weight: 700;
  line-height: 1.3;
}

/* H3 - Subsections */
.section-title {
  font-size: 20px;
  font-weight: 700;
  line-height: 1.4;
}

/* Body Large */
.player-name {
  font-size: 16px;
  font-weight: 600;
  line-height: 1.5;
}

/* Body */
body, .form-input, .btn {
  font-size: 14-16px;
  font-weight: 400-600;
  line-height: 1.5;
}

/* Small */
.player-stats, .form-hint {
  font-size: 12-13px;
  font-weight: 400-500;
  line-height: 1.4;
}

/* Tiny */
.form-label, .achievement-date {
  font-size: 11-12px;
  font-weight: 600;
  line-height: 1.3;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* Stats (Display Numbers) */
.stat-value {
  font-size: 28px;
  font-weight: 700;
  line-height: 1;
}

/* Wrapped Stats (Extra Large) */
.wrapped-stat-value {
  font-size: 4em;  /* 64px typically */
  font-weight: 800;
  line-height: 1;
}
```

---

### 3.3 Text Styles

**Gradient Text:**
```css
.logo-text {
  background: linear-gradient(135deg, var(--text-primary), var(--accent-cyan));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
```

**Text Shadows:**
```css
/* Wrapped title */
text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);

/* Large numbers */
text-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
```

**Letter Spacing:**
```css
/* Labels (uppercase) */
letter-spacing: 0.5-1px;

/* Tagline */
letter-spacing: 2px;

/* Group codes */
letter-spacing: 3px;
```

---

## 4. Component Library

### 4.1 Glass Card

**Base Component:**
```css
.glass-card {
  background: var(--glass-bg);
  border: 1px solid var(--glass-border);
  border-radius: 16-24px;
  padding: 20-30px;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  transition: all 0.3s ease;
}

.glass-card:hover {
  transform: translateY(-5px);
  border-color: rgba(255, 255, 255, 0.2);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}
```

**Variants:**

**Header Card:**
```css
.glass-card.header {
  border-radius: 20px;
  padding: 15px 30px;
  display: inline-flex;
}
```

**Wrapped Card:**
```css
.wrapped-player-card {
  background: linear-gradient(135deg, #f39c12 0%, #e74c3c 100%);
  /* Solid gradient, not glass */
  border-radius: 20px;
  padding: 30px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}
```

---

### 4.2 Buttons

**Primary Button:**
```css
.btn-primary {
  background: linear-gradient(135deg, var(--accent-purple), var(--accent-cyan));
  color: white;
  box-shadow: 0 10px 30px rgba(99, 102, 241, 0.3);
  padding: 16px 24px;
  border: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  font-family: 'Outfit', sans-serif;
  position: relative;
  overflow: hidden;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 15px 40px rgba(99, 102, 241, 0.4);
}

/* Ripple effect */
.btn-primary::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.2);
  transform: translate(-50%, -50%);
  transition: width 0.6s, height 0.6s;
}

.btn-primary:active::before {
  width: 300px;
  height: 300px;
}
```

**Secondary Button:**
```css
.btn-secondary {
  background: var(--glass-bg);
  border: 2px solid var(--glass-border);
  color: var(--text-primary);
  backdrop-filter: blur(10px);
  padding: 16px 24px;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-secondary:hover {
  background: rgba(255, 255, 255, 0.1);
  border-color: rgba(255, 255, 255, 0.3);
}
```

**Danger Button:**
```css
.btn-danger {
  background: rgba(239, 68, 68, 0.1);
  border: 1px solid var(--error);
  color: var(--error);
  padding: 16px 24px;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-danger:hover {
  background: rgba(239, 68, 68, 0.2);
}
```

**Small Button (btn-small):**
```css
.btn-small {
  padding: 8px 16px;
  font-size: 12-14px;
}
```

**Icon Button:**
```css
.icon-btn {
  background: var(--glass-bg);
  border: 1px solid var(--glass-border);
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 18px;
}

.icon-btn:hover {
  background: rgba(255, 255, 255, 0.1);
  transform: scale(1.1);
}
```

---

### 4.3 Form Elements

**Text Input:**
```css
.form-input {
  width: 100%;
  padding: 12-14px;
  background: rgba(255, 255, 255, 0.05);
  border: 2px solid var(--glass-border);
  border-radius: 10-12px;
  color: var(--text-primary);
  font-size: 14-16px;
  font-family: 'Outfit', sans-serif;
  transition: all 0.3s ease;
}

.form-input:focus {
  outline: none;
  border-color: var(--accent-cyan);
  background: rgba(255, 255, 255, 0.08);
  box-shadow: 0 0 0 3-4px rgba(6, 182, 212, 0.1);
}

.form-input::placeholder {
  color: rgba(203, 213, 225, 0.5);
}
```

**Select Dropdown:**
```css
.form-select {
  width: 100%;
  padding: 12px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--glass-border);
  border-radius: 10px;
  color: var(--text-primary);
  font-size: 14px;
  font-family: 'Outfit', sans-serif;
  transition: all 0.3s ease;
  cursor: pointer;
}

.form-select:focus {
  outline: none;
  border-color: var(--accent-cyan);
  background: rgba(255, 255, 255, 0.08);
}
```

**Textarea:**
```css
.form-textarea {
  width: 100%;
  padding: 12px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--glass-border);
  border-radius: 10px;
  color: var(--text-primary);
  font-size: 14px;
  font-family: 'Outfit', sans-serif;
  resize: vertical;
  min-height: 80px;
  transition: all 0.3s ease;
}
```

**Form Label:**
```css
.form-label {
  display: block;
  font-size: 13-14px;
  font-weight: 600;
  color: var(--text-secondary);
  margin-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
```

**Form Hint:**
```css
.form-hint {
  font-size: 12px;
  color: var(--text-secondary);
  margin-top: 6px;
  opacity: 0.8;
}
```

---

### 4.4 Cards & Containers

**Player Card:**
```css
.player-card {
  background: var(--glass-bg);
  border: 1px solid var(--glass-border);
  border-radius: 12px;
  padding: 15px;
  margin-bottom: 12px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: all 0.3s ease;
  cursor: pointer;  /* If clickable */
}

.player-card:hover {
  background: rgba(255, 255, 255, 0.08);
  transform: translateX(5px);
}
```

**HTML Structure:**
```html
<div class="player-card">
  <div class="player-info">
    <div class="player-name">Alice</div>
    <div class="player-stats">10 games • 6 wins • 60% win rate</div>
    <div class="player-stats" style="font-size: 11px; opacity: 0.7;">
      Joined: Feb 2024
    </div>
  </div>
  <div class="player-winnings positive">+$250.00</div>
</div>
```

**Stat Card:**
```css
.stat-card {
  background: var(--glass-bg);
  border: 1px solid var(--glass-border);
  border-radius: 12px;
  padding: 15-20px;
  text-align: center;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  background: linear-gradient(135deg, var(--accent-cyan), var(--accent-purple));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 5px;
}

.stat-label {
  font-size: 12px;
  color: var(--text-secondary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
```

**Achievement Badge:**
```css
.achievement-badge {
  background: linear-gradient(135deg, 
    rgba(99, 102, 241, 0.1), 
    rgba(6, 182, 212, 0.1)
  );
  border: 1px solid var(--accent-purple);
  border-radius: 12px;
  padding: 15px;
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  gap: 15px;
  transition: all 0.3s ease;
}

.achievement-badge:hover {
  background: linear-gradient(135deg, 
    rgba(99, 102, 241, 0.15), 
    rgba(6, 182, 212, 0.15)
  );
  transform: translateX(5px);
}

/* Anniversary variant */
.achievement-badge.anniversary {
  background: linear-gradient(135deg, 
    rgba(241, 196, 15, 0.2), 
    rgba(230, 126, 34, 0.2)
  );
  border: 2px solid #f39c12;
}
```

---

### 4.5 Modals

**Modal Overlay:**
```css
.modal {
  display: none;  /* Hidden by default */
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(10, 14, 39, 0.95);
  backdrop-filter: blur(10px);
  z-index: 1000;
  padding: 20px;
  overflow-y: auto;
}

.modal.active {
  display: flex;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.3s ease-out;
}
```

**Modal Content:**
```css
.modal-content {
  background: var(--primary-blue);
  border: 1px solid var(--glass-border);
  border-radius: 20-24px;
  padding: 25-30px;
  max-width: 480-500px;
  width: 100%;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
  animation: scaleIn 0.3s ease-out;
}
```

**Modal Header:**
```css
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20-25px;
}

.modal-close {
  background: rgba(255, 255, 255, 0.1);
  border: none;
  width: 32-36px;
  height: 32-36px;
  border-radius: 50%;
  color: var(--text-primary);
  font-size: 20-24px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.modal-close:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: rotate(90deg);
}
```

---

### 4.6 Tables

**Responsive Table Wrapper:**
```css
.table-responsive {
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
```

**Table Styling:**
```css
table {
  width: 100%;
  border-collapse: collapse;
}

th {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid var(--glass-border);
  font-size: 12px;
  font-weight: 600;
  color: var(--text-secondary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid var(--glass-border);
  font-size: 14px;
  color: var(--text-primary);
}

tr:hover {
  background: rgba(255, 255, 255, 0.03);
}
```

**4-Column Night Results Table:**
```html
<table>
  <thead>
    <tr>
      <th>Player</th>
      <th>Buy-in</th>
      <th>Cash Out</th>
      <th>Net</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Alice</td>
      <td style="color: var(--text-secondary);">$40.00</td>
      <td style="color: var(--text-secondary);">$70.00</td>
      <td style="color: var(--success); font-weight: 600;">+$30.00</td>
    </tr>
  </tbody>
</table>
```

---

### 4.7 Tabs

**Tab Container:**
```css
.tabs {
  display: flex;
  gap: 8-10px;
  margin-bottom: 20px;
  overflow-x: auto;
  padding-bottom: 5px;
  -webkit-overflow-scrolling: touch;
}

.tabs::-webkit-scrollbar {
  height: 4px;
}

.tabs::-webkit-scrollbar-track {
  background: var(--glass-bg);
  border-radius: 2px;
}

.tabs::-webkit-scrollbar-thumb {
  background: var(--accent-purple);
  border-radius: 2px;
}
```

**Tab Button:**
```css
.tab {
  padding: 12px 20px;
  background: var(--glass-bg);
  border: 1px solid var(--glass-border);
  border-radius: 12px;
  color: var(--text-secondary);
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  backdrop-filter: blur(10px);
}

.tab:hover {
  background: rgba(255, 255, 255, 0.1);
}

.tab.active {
  background: linear-gradient(135deg, var(--accent-purple), var(--accent-cyan));
  border-color: transparent;
  color: white;
  box-shadow: 0 5px 20px rgba(99, 102, 241, 0.3);
}
```

**Tab Content:**
```css
.tab-content {
  display: none;
  animation: fadeIn 0.3s ease-out;
}

.tab-content.active {
  display: block;
}
```

---

### 4.8 Notifications

**Toast Notification:**
```css
.toast {
  position: fixed;
  bottom: 100px;
  left: 50%;
  transform: translateX(-50%) translateY(100px);
  background: var(--success);
  color: white;
  padding: 15px 25px;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  z-index: 2000;
  opacity: 0;
  transition: all 0.3s ease;
  font-size: 14-16px;
  font-weight: 600;
}

.toast.show {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}

.toast.error {
  background: var(--error);
}
```

**Usage:**
```javascript
showToast('Player added!');           // Green success
showToast('Invalid password', true);  // Red error
```

---

### 4.9 Loading States

**Spinner:**
```css
.spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-top-color: white;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
```

**Usage:**
```javascript
// Before async operation
button.innerHTML = '<span class="spinner"></span>';
button.disabled = true;

// After completion
button.innerHTML = '<span>Create Group</span>';
button.disabled = false;
```

---

### 4.10 Empty States

**Structure:**
```html
<div class="empty-state">
  <div class="empty-icon">🎲</div>
  <div class="empty-text">No poker nights yet</div>
  <button class="btn btn-primary" onclick="openAddNightModal()">
    Add First Night
  </button>
</div>
```

**Styling:**
```css
.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: var(--text-secondary);
}

.empty-icon {
  font-size: 64px;
  margin-bottom: 15px;
  opacity: 0.3;
}

.empty-text {
  font-size: 16-18px;
  margin-bottom: 20px;
}
```

**Variants:**
- No data: Generic empty state with icon
- No search results: 🔍 icon with "No results match..."
- All settled: ✅ icon with "All settled up!"

---

## 5. Animations & Transitions

### 5.1 Page Load Animations

```css
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes scaleIn {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
```

**Application:**
```css
.logo-section {
  animation: fadeInDown 0.8s ease-out;
}

.glass-card {
  animation: fadeInUp 0.8s ease-out;
}

.modal-content {
  animation: scaleIn 0.3s ease-out;
}
```

---

### 5.2 Fortune Cookie Animations

**Shake Animation:**
```css
@keyframes shake {
  0%, 100% { transform: rotate(0deg); }
  25% { transform: rotate(-10deg); }
  75% { transform: rotate(10deg); }
}

.shake {
  animation: shake 0.5s ease-in-out;
}
```

**Break Animation:**
```css
@keyframes break {
  0% { 
    transform: scale(1) rotate(0deg); 
    opacity: 1; 
  }
  100% { 
    transform: scale(1.5) rotate(20deg); 
    opacity: 0; 
  }
}

.break {
  animation: break 0.5s ease-in-out forwards;
}
```

**Reveal Animation:**
```css
@keyframes fortuneReveal {
  0% { 
    opacity: 0; 
    transform: translateY(30px) scale(0.5); 
  }
  100% { 
    opacity: 1; 
    transform: translateY(0) scale(1); 
  }
}

.fortune-revealed {
  animation: fortuneReveal 0.8s ease-out;
}
```

**Sequence Implementation:**
```javascript
function openFortuneCookie(playerId) {
  const container = document.getElementById('fortune-' + playerId);
  const icon = container.querySelector('.fortune-cookie-icon');
  
  // Phase 1: Shake (0.5s)
  icon.classList.add('shake');
  
  setTimeout(() => {
    // Phase 2: Break (0.5s)
    icon.classList.remove('shake');
    icon.classList.add('break');
    
    setTimeout(() => {
      // Phase 3: Reveal (0.8s)
      const fortune = getRandomFortune();
      container.innerHTML = fortuneHTML;
      container.className = 'fortune-revealed';
      container.onclick = null;
    }, 500);
  }, 500);
}
```

---

### 5.3 Background Animations

**Floating Poker Chips:**
```css
@keyframes float {
  0%, 100% { transform: translate(0, 0) rotate(0deg); }
  33% { transform: translate(30px, -30px) rotate(120deg); }
  66% { transform: translate(-20px, 20px) rotate(240deg); }
}

.poker-chip {
  width: 200px;
  height: 200px;
  border-radius: 50%;
  background: radial-gradient(circle, var(--accent-purple) 0%, transparent 70%);
  opacity: 0.1;
  animation: float 20s infinite ease-in-out;
  position: fixed;
  pointer-events: none;
}

.chip-1 { 
  top: 10%; 
  left: -5%; 
  animation-delay: 0s; 
}

.chip-2 { 
  bottom: 20%; 
  right: -5%; 
  background: radial-gradient(circle, var(--accent-cyan) 0%, transparent 70%);
  animation-delay: 7s; 
}

.chip-3 { 
  top: 60%; 
  left: 10%; 
  width: 150px; 
  height: 150px;
  animation-delay: 14s; 
}
```

---

### 5.4 Hover Effects

**Card Hover:**
```css
.glass-card:hover {
  transform: translateY(-5px);
  border-color: rgba(255, 255, 255, 0.2);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}
```

**Player Card Hover:**
```css
.player-card:hover {
  background: rgba(255, 255, 255, 0.08);
  transform: translateX(5px);
}
```

**Button Hover:**
```css
.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 15px 40px rgba(99, 102, 241, 0.4);
}
```

**Icon Button Hover:**
```css
.icon-btn:hover {
  background: rgba(255, 255, 255, 0.1);
  transform: scale(1.1);
}
```

---

## 6. Layout Patterns

### 6.1 Grid Layouts

**Stats Grid (2x2):**
```css
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150-200px, 1fr));
  gap: 15px;
  margin-bottom: 20px;
}
```

**Wrapped Stats (2x2, Fixed):**
```css
.wrapped-stats-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 15px;
  margin-bottom: 25px;
}
```

**Settlement 3-Column:**
```css
display: grid;
grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
gap: 15px;
```

**Control Grids (Search + Sort):**
```css
/* 2 columns */
display: grid;
grid-template-columns: 1fr 1fr;
gap: 15px;

/* 3 columns (achievements) */
display: grid;
grid-template-columns: 1fr 1fr 1fr;
gap: 15px;
```

---

### 6.2 Flexbox Patterns

**Header:**
```css
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left, .header-right {
  display: flex;
  align-items: center;
  gap: 15px;
}
```

**Card Header:**
```css
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}
```

**Player Card:**
```css
.player-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
```

**Achievement Badge:**
```css
.achievement-badge {
  display: flex;
  align-items: center;
  gap: 15px;
}
```

---

### 6.3 Responsive Behavior

**Mobile (< 480px):**
```css
@media (max-width: 480px) {
  .container {
    padding: 15px;
  }
  
  .logo-text {
    font-size: 24px;
  }
  
  .glass-card {
    padding: 20px;
  }
  
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
```

**Tablet (480px - 768px):**
```css
@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .tabs {
    gap: 6px;
  }
  
  .tab {
    padding: 10px 16px;
    font-size: 13px;
  }
  
  table {
    font-size: 13px;
  }
  
  th, td {
    padding: 10px 8px;
  }
}
```

**Desktop (> 768px):**
- Default styles
- Maximum container width: 900-1200px
- Centered with auto margins

---

## 7. Icon System

### 7.1 Emoji Icons

**Why Emojis:**
- No icon library needed
- Universal rendering
- Colorful and expressive
- Large file size savings
- Work everywhere (UTF-8)

**Icon Usage:**

**Navigation Tabs:**
- 📊 Dashboard
- 🎲 Poker Nights
- 👥 Players
- 🏆 Leaderboard
- 🎖️ Achievements
- 📈 Stats
- 💰 Settlement
- 🎁 Wrapped

**Actions:**
- ➕ Add
- ✏️ Edit
- 🗑️ Delete
- ✓ Mark as Paid
- 🏠 Home
- ⚙️ Settings
- 👁️ Viewer Mode
- ← Back
- × Close

**Status:**
- ✅ Success/Balanced
- ⚠️ Warning/Unbalanced
- ● Unpaid (bullet point)
- 💵 Expense

**Medals:**
- 🥇 1st Place
- 🥈 2nd Place
- 🥉 3rd Place

**Achievements:**
- 🎯 Welcome to Club
- 🎲 Veteran Player
- ⭐ Dedication
- 🏆 High Roller
- 🔥 Hot Streak
- 💰 Big Winner
- 💎 Profit Master
- 💀 Grim Reaper
- 🔒 Fortress
- 🏦 Bankroll Builder
- 🎂 Anniversary

**Card Suits:**
- ♠ Spades
- ♥ Hearts
- ♦ Diamonds
- ♣ Clubs

---

## 8. Spacing System

### 8.1 Spacing Scale

```css
/* 4px base unit */
--space-1: 4px;
--space-2: 8px;
--space-3: 12px;
--space-4: 16px;
--space-5: 20px;
--space-6: 24px;
--space-8: 32px;
--space-10: 40px;
--space-12: 48px;
--space-16: 64px;
```

**Common Applications:**
```css
/* Gaps */
gap: 8px;   /* Small spacing */
gap: 15px;  /* Medium spacing */
gap: 20px;  /* Large spacing */

/* Padding */
padding: 15px;     /* Card padding (mobile) */
padding: 20-30px;  /* Card padding (desktop) */
padding: 12px;     /* Form input */

/* Margins */
margin-bottom: 12px;  /* Between cards */
margin-bottom: 20px;  /* Between sections */
margin-bottom: 25px;  /* Between major sections */
```

---

### 8.2 Container Widths

```css
/* Mobile first (default) */
.container {
  max-width: 100%;
  padding: 15-20px;
}

/* Desktop */
.container {
  max-width: 900-1200px;
  margin: 0 auto;
}

/* Modal content */
.modal-content {
  max-width: 480-500px;
}

/* Wide modal (settlement) */
.modal-content.wide {
  max-width: 900px;
}
```

---

## 9. Accessibility Features

### 9.1 Color Contrast

**All text meets WCAG AA (4.5:1 minimum):**
- White text on dark blue: 12:1 ✅
- Gray text on dark blue: 6:1 ✅
- Green on dark: 5.5:1 ✅
- Red on dark: 5:1 ✅

**AAA Compliance (7:1) for Large Text:**
- All headings exceed 7:1
- Stat numbers exceed 7:1

---

### 9.2 Keyboard Navigation

**Tab Order:**
- Follows visual flow (top to bottom, left to right)
- Modal close button is first in modal
- Form fields in logical order
- Submit button last

**Focus Styles:**
```css
.form-input:focus,
.form-select:focus,
.btn:focus {
  outline: none;
  box-shadow: 0 0 0 3px rgba(6, 182, 212, 0.1);
  border-color: var(--accent-cyan);
}
```

**Skip Links (Future):**
```html
<a href="#main-content" class="skip-link">Skip to main content</a>
```

---

### 9.3 Semantic HTML

```html
<!-- Structure -->
<header class="header">...</header>
<main class="container">...</main>

<!-- Forms -->
<label for="playerName" class="form-label">Player Name</label>
<input id="playerName" type="text" class="form-input">

<!-- Tables -->
<table>
  <thead>
    <tr><th>...</th></tr>
  </thead>
  <tbody>
    <tr><td>...</td></tr>
  </tbody>
</table>

<!-- Buttons -->
<button type="button" class="btn">...</button>
```

---

## 10. Responsive Images & Media

### 10.1 No Images Used

**Why:**
- Faster load time
- No bandwidth for images
- Emojis replace icons
- CSS creates all visual effects
- Smaller total app size

**Future Consideration:**
- Logo PNG/SVG for branding
- Player avatars (optional)
- Night photos (V4 feature)

---

## 11. Print Styles

### 11.1 Not Currently Implemented

**Future Enhancement:**
```css
@media print {
  /* Hide navigation */
  .header, .tabs { display: none; }
  
  /* Show all content */
  .tab-content { display: block !important; }
  
  /* Remove backgrounds */
  background: white !important;
  color: black !important;
  
  /* Page breaks */
  .glass-card { page-break-inside: avoid; }
}
```

**Use Cases:**
- Print leaderboard
- Print year-end wrapped
- Print settlement list

---

## 12. Dark Mode

### 12.1 Current Implementation

**Always Dark:**
- No light mode toggle
- Dark theme by design
- Optimized for low-light poker environments

**Rationale:**
- Poker often played in evening
- Dark theme reduces eye strain
- Fits aesthetic (casino/night vibe)
- Simpler (one theme to maintain)

### 12.2 Future Light Mode

**If Implementing:**
```css
:root {
  --bg-primary: #0a0e27;  /* Dark */
  --text-primary: #f8fafc; /* Light */
}

:root[data-theme="light"] {
  --bg-primary: #ffffff;  /* Light */
  --text-primary: #0a0e27; /* Dark */
}
```

**Toggle:**
```javascript
function toggleTheme() {
  const root = document.documentElement;
  const currentTheme = root.getAttribute('data-theme');
  root.setAttribute('data-theme', currentTheme === 'light' ? 'dark' : 'light');
  localStorage.setItem('theme', currentTheme === 'light' ? 'dark' : 'light');
}
```

---

## 13. Component Composition Examples

### 13.1 Night Card (Complete)

```html
<div class="glass-card" style="margin-bottom: 12px;">
  <!-- Header -->
  <div class="card-header">
    <div>
      <div class="card-title">Feb 5, 2024</div>
      <div style="font-size: 12px; color: var(--text-secondary);">
        Bob's House • Buy-in: $20.00
      </div>
    </div>
    <div style="display: flex; gap: 8px;">
      <button class="btn btn-secondary btn-small" onclick="editNight(0)">✏️</button>
      <button class="btn btn-danger btn-small" onclick="deleteNight(0)">🗑️</button>
    </div>
  </div>
  
  <!-- Winner -->
  <div style="font-size: 14px; color: var(--text-secondary); margin-bottom: 10px;">
    Winner: <strong style="color: var(--success);">Alice</strong> (+$30.00)
  </div>
  
  <!-- Results Table -->
  <div class="table-responsive">
    <table>
      <thead>
        <tr>
          <th>Player</th>
          <th>Buy-in</th>
          <th>Cash Out</th>
          <th>Net</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Alice</td>
          <td style="color: var(--text-secondary);">$40.00</td>
          <td style="color: var(--text-secondary);">$70.00</td>
          <td style="color: var(--success); font-weight: 600;">+$30.00</td>
        </tr>
        <tr>
          <td>Bob</td>
          <td style="color: var(--text-secondary);">$20.00</td>
          <td style="color: var(--text-secondary);">$5.00</td>
          <td style="color: var(--error); font-weight: 600;">-$15.00</td>
        </tr>
      </tbody>
    </table>
  </div>
  
  <!-- Expenses -->
  <div style="margin-top: 10px; padding: 10px; background: rgba(6, 182, 212, 0.1); border: 1px solid var(--accent-cyan); border-radius: 8px;">
    <div style="font-size: 12px; font-weight: 600; color: var(--accent-cyan); margin-bottom: 8px; text-transform: uppercase;">
      Expenses
    </div>
    <div style="font-size: 13px; margin-bottom: 4px;">
      💵 Alice paid $30.00 • Pizza
    </div>
  </div>
  
  <!-- Notes -->
  <div style="margin-top: 10px; padding: 10px; background: rgba(255,255,255,0.03); border-radius: 8px; font-size: 13px;">
    Epic comeback by Alice!
  </div>
</div>
```

---

### 13.2 Balance Check Indicator (Complete)

```html
<div id="balanceCheck" style="
  margin-top: 15px;
  padding: 15px;
  border-radius: 12px;
  text-align: center;
  font-weight: 700;
  font-size: 16px;
  display: block;
  background: rgba(16, 185, 129, 0.2);
  border: 2px solid #10b981;
  color: #10b981;">
  
  <div style="font-size: 13px; font-weight: 600; margin-bottom: 5px; opacity: 0.8;">
    Balance Check
  </div>
  
  <div id="balanceAmount">
    ✅ Balanced! Buy-in: $80.00 = Cash Out: $80.00
  </div>
</div>
```

**Red (Unbalanced) State:**
```javascript
balanceCheck.style.background = 'rgba(239, 68, 68, 0.2)';
balanceCheck.style.border = '2px solid var(--error)';
balanceCheck.style.color = 'var(--error)';
balanceAmount.innerHTML = `
  ⚠️ Off by +$10.00<br>
  <small style="font-size: 12px; opacity: 0.8;">
    Buy-in: $80.00 • Cash Out: $90.00
  </small>
`;
```

---

## 14. Animation Timing

### 14.1 Duration Standards

```css
/* Micro-interactions */
transition: 0.15s;  /* Hover color changes */

/* Standard transitions */
transition: 0.3s;   /* Most hover effects, modals */

/* Slow transitions */
transition: 0.6s;   /* Ripple effects */

/* Animations */
animation: 0.3s;    /* Fade in */
animation: 0.5s;    /* Shake, break */
animation: 0.8s;    /* Fortune reveal */
animation: 20s;     /* Background float */
```

### 14.2 Easing Functions

```css
/* Default */
ease-out  /* Most animations (natural deceleration) */

/* Specific uses */
ease-in-out  /* Float animation (smooth) */
linear       /* Spinner rotation */
ease         /* General fallback */
```

---

## 15. Visual Hierarchy

### 15.1 Information Priority

**Level 1 (Highest):**
- Page title / Group name
- Primary action buttons
- Error messages
- Balance check indicator

**Level 2:**
- Tab navigation
- Section headings
- Important stats (winnings)

**Level 3:**
- Card content
- Table data
- Form fields

**Level 4:**
- Labels
- Hints
- Timestamps
- Secondary info

**Level 5 (Lowest):**
- Decorative elements
- Background patterns
- Subtle gradients

---

### 15.2 Visual Weight Distribution

**Heavy (Draws Attention):**
- Large font sizes (28px+)
- Bold weights (700-800)
- Bright colors (cyan, purple)
- Gradients
- Shadows and glows

**Medium:**
- Standard sizes (14-16px)
- Medium weights (500-600)
- Primary text color
- Borders

**Light:**
- Small sizes (11-12px)
- Regular weight (400)
- Secondary text color
- High transparency

---

**END OF PART 3**

Continue to Part 4 for Detailed Feature Specifications →
